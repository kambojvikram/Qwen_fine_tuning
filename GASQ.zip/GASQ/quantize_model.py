"""
GASQ Quantization - Main Script
Complete end-to-end quantization pipeline for 7B parameter models
"""

import argparse
import json
import torch
from torch.utils.data import DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
import logging
from pathlib import Path

from gasq_quantizer import GASQQuantizer
from awq_scorer import compute_awq_scores_simple
from gptq_scorer import compute_gptq_scores_simple

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def load_calibration_data(
    dataset_name: str,
    tokenizer,
    num_samples: int = 512,
    seq_length: int = 512
):
    """
    Load and prepare calibration dataset for AWQ/GPTQ scoring.
    
    Args:
        dataset_name: HuggingFace dataset name or 'sql' for text-to-sql
        tokenizer: Model tokenizer
        num_samples: Number of calibration samples
        seq_length: Maximum sequence length
    
    Returns:
        DataLoader with calibration data
    """
    logger.info(f"Loading calibration dataset: {dataset_name}")
    
    if dataset_name == 'sql':
        # Text-to-SQL calibration data
        dataset = load_dataset("gretelai/synthetic_text_to_sql", split="train")
        dataset = dataset.shuffle(seed=42).select(range(min(num_samples, len(dataset))))
        
        def prepare_sample(example):
            text = f"Question: {example['sql_prompt']}\nSQL: {example['sql']}"
            return tokenizer(
                text,
                max_length=seq_length,
                truncation=True,
                padding='max_length',
                return_tensors='pt'
            )
    
    elif dataset_name == 'wikitext':
        # General text calibration
        dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
        dataset = dataset.shuffle(seed=42).select(range(min(num_samples, len(dataset))))
        
        def prepare_sample(example):
            return tokenizer(
                example['text'],
                max_length=seq_length,
                truncation=True,
                padding='max_length',
                return_tensors='pt'
            )
    
    else:
        # Custom dataset
        dataset = load_dataset(dataset_name, split="train")
        dataset = dataset.shuffle(seed=42).select(range(min(num_samples, len(dataset))))
        
        def prepare_sample(example):
            # Assume first text field
            text_field = [k for k in example.keys() if 'text' in k.lower()][0]
            return tokenizer(
                example[text_field],
                max_length=seq_length,
                truncation=True,
                padding='max_length',
                return_tensors='pt'
            )
    
    # Tokenize dataset
    tokenized = []
    for example in dataset:
        tokens = prepare_sample(example)
        tokenized.append({
            'input_ids': tokens['input_ids'].squeeze(0),
            'attention_mask': tokens['attention_mask'].squeeze(0)
        })
    
    # Create dataloader
    def collate_fn(batch):
        return {
            'input_ids': torch.stack([x['input_ids'] for x in batch]),
            'attention_mask': torch.stack([x['attention_mask'] for x in batch])
        }
    
    dataloader = DataLoader(
        tokenized,
        batch_size=1,  # Process one at a time for stability
        shuffle=False,
        collate_fn=collate_fn
    )
    
    logger.info(f"Prepared {len(tokenized)} calibration samples")
    return dataloader


def apply_gasq_quantization(
    model_name: str,
    gradient_stats_path: str,
    output_dir: str,
    calibration_dataset: str = "sql",
    target_avg_bits: float = 4.0,
    num_calibration_samples: int = 512,
    device: str = "cuda"
):
    """
    Complete GASQ quantization pipeline.
    
    Args:
        model_name: HuggingFace model name or path
        gradient_stats_path: Path to gradient statistics JSON from fine-tuning
        output_dir: Directory to save quantized model
        calibration_dataset: Dataset for AWQ/GPTQ calibration
        target_avg_bits: Target average bit width (4.0-5.0)
        num_calibration_samples: Number of samples for calibration
        device: Device to use
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Step 1: Load model and tokenizer
    logger.info(f"Loading model: {model_name}")
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # Step 2: Load calibration data
    calibration_loader = load_calibration_data(
        calibration_dataset,
        tokenizer,
        num_samples=num_calibration_samples
    )
    
    # Step 3: Compute AWQ scores
    logger.info("=" * 60)
    logger.info("STEP 1/4: Computing AWQ scores...")
    logger.info("=" * 60)
    awq_scores = compute_awq_scores_simple(
        model,
        calibration_loader,
        device=device,
        num_batches=min(128, num_calibration_samples)
    )
    
    # Save AWQ scores
    awq_path = output_path / "awq_scores.json"
    with open(awq_path, 'w') as f:
        json.dump(awq_scores, f, indent=2)
    logger.info(f"Saved AWQ scores to {awq_path}")
    
    # Step 4: Compute GPTQ sensitivity scores
    logger.info("=" * 60)
    logger.info("STEP 2/4: Computing GPTQ sensitivity scores...")
    logger.info("=" * 60)
    gptq_scores = compute_gptq_scores_simple(
        model,
        calibration_loader,
        device=device,
        num_batches=min(128, num_calibration_samples)
    )
    
    # Save GPTQ scores
    gptq_path = output_path / "gptq_scores.json"
    with open(gptq_path, 'w') as f:
        json.dump(gptq_scores, f, indent=2)
    logger.info(f"Saved GPTQ scores to {gptq_path}")
    
    # Step 5: Combine with gradient stats using GASQ
    logger.info("=" * 60)
    logger.info("STEP 3/4: Computing GASQ combined scores...")
    logger.info("=" * 60)
    gasq = GASQQuantizer(
        gradient_stats_path=gradient_stats_path,
        target_avg_bits=target_avg_bits,
        adaptive_weights=True,
        conservative=True
    )
    
    # Add AWQ and GPTQ scores
    gasq.awq_scores = awq_scores
    gasq.gptq_scores = gptq_scores
    
    # Compute combined scores
    gasq.compute_combined_scores()
    
    # Allocate bits
    gasq.allocate_bits()
    
    # Save GASQ report
    report_path = output_path / "gasq_report.json"
    report = gasq.save_report(str(report_path))
    
    # Step 6: Apply quantization using AutoGPTQ
    logger.info("=" * 60)
    logger.info("STEP 4/4: Applying mixed-precision quantization...")
    logger.info("=" * 60)
    
    try:
        from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
        from auto_gptq.modeling._const import SUPPORTED_MODELS
        
        # Create quantization config
        # Note: AutoGPTQ typically uses uniform bits, so we need custom approach
        logger.info("Using AutoGPTQ for quantization...")
        
        # For now, we'll quantize to average bits as baseline
        # Custom mixed-precision requires modifying AutoGPTQ internals
        avg_bits = int(round(target_avg_bits))
        
        quantize_config = BaseQuantizeConfig(
            bits=avg_bits,
            group_size=128,
            desc_act=True,
            sym=True,
            true_sequential=True,
        )
        
        # Quantize model
        model_quantized = AutoGPTQForCausalLM.from_pretrained(
            model_name,
            quantize_config=quantize_config,
            device_map="auto"
        )
        
        # Prepare calibration data for GPTQ
        calibration_samples = []
        for i, batch in enumerate(calibration_loader):
            if i >= 128:  # GPTQ uses 128 samples typically
                break
            calibration_samples.append({
                'input_ids': batch['input_ids'],
                'attention_mask': batch['attention_mask']
            })
        
        # Quantize
        model_quantized.quantize(calibration_samples)
        
        # Save quantized model
        save_path = output_path / "quantized_model"
        model_quantized.save_quantized(str(save_path))
        tokenizer.save_pretrained(str(save_path))
        
        logger.info(f"Saved quantized model to {save_path}")
        
    except ImportError:
        logger.warning("AutoGPTQ not installed. Saving bit allocation config only.")
        logger.info("To apply quantization, install: pip install auto-gptq")
        
        # Save config for manual quantization
        config_path = output_path / "bit_allocation.json"
        with open(config_path, 'w') as f:
            json.dump(gasq.bit_allocations, f, indent=2)
        logger.info(f"Saved bit allocation to {config_path}")
    
    # Print summary
    logger.info("=" * 60)
    logger.info("GASQ Quantization Complete!")
    logger.info("=" * 60)
    logger.info(f"Average bits: {report['results']['avg_bits']:.2f}")
    logger.info(f"Compression: {report['results']['compression_ratio']:.2f}x")
    logger.info(f"8-bit layers: {report['results']['bit_distribution']['8-bit']}")
    logger.info(f"6-bit layers: {report['results']['bit_distribution']['6-bit']}")
    logger.info(f"4-bit layers: {report['results']['bit_distribution']['4-bit']}")
    logger.info(f"Output directory: {output_path}")
    
    return model, gasq


def main():
    parser = argparse.ArgumentParser(
        description="GASQ: Gradient-Activation Selective Quantization for 7B Models"
    )
    
    parser.add_argument(
        "--model_name",
        type=str,
        required=True,
        help="HuggingFace model name or path (e.g., Qwen/Qwen-7B)"
    )
    
    parser.add_argument(
        "--gradient_stats",
        type=str,
        required=True,
        help="Path to gradient statistics JSON from fine-tuning"
    )
    
    parser.add_argument(
        "--output_dir",
        type=str,
        required=True,
        help="Directory to save quantized model and reports"
    )
    
    parser.add_argument(
        "--calibration_dataset",
        type=str,
        default="sql",
        help="Calibration dataset: 'sql', 'wikitext', or HF dataset name"
    )
    
    parser.add_argument(
        "--target_bits",
        type=float,
        default=4.0,
        help="Target average bit width (4.0-5.0 recommended)"
    )
    
    parser.add_argument(
        "--num_calibration_samples",
        type=int,
        default=512,
        help="Number of calibration samples"
    )
    
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        help="Device to use (cuda or cpu)"
    )
    
    args = parser.parse_args()
    
    # Run GASQ quantization
    apply_gasq_quantization(
        model_name=args.model_name,
        gradient_stats_path=args.gradient_stats,
        output_dir=args.output_dir,
        calibration_dataset=args.calibration_dataset,
        target_avg_bits=args.target_bits,
        num_calibration_samples=args.num_calibration_samples,
        device=args.device
    )


if __name__ == "__main__":
    main()
