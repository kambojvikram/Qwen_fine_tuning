"""
QLoRA Fine-tuning with Gradient Tracking for GASQ
Complete training script that tracks gradient statistics during fine-tuning
"""

import argparse
import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from datasets import load_dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from gradient_tracker import GradientStatTracker
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def load_model_and_tokenizer(
    model_name: str,
    load_in_4bit: bool = True
):
    """Load model with QLoRA configuration"""
    from transformers import BitsAndBytesConfig
    
    # Quantization config for loading base model
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=load_in_4bit,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    
    logger.info(f"Loading model: {model_name}")
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
    )
    
    tokenizer = AutoTokenizer.from_pretrained(
        model_name,
        trust_remote_code=True
    )
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id
    
    # Prepare model for training
    model = prepare_model_for_kbit_training(model)
    
    return model, tokenizer


def setup_lora(model, lora_r: int = 16, lora_alpha: int = 32):
    """Setup LoRA adapters"""
    lora_config = LoraConfig(
        r=lora_r,
        lora_alpha=lora_alpha,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", 
                       "gate_proj", "up_proj", "down_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    return model


def load_dataset_for_task(
    dataset_name: str,
    tokenizer,
    max_length: int = 512
):
    """Load and prepare dataset"""
    if dataset_name == "sql":
        # Text-to-SQL dataset
        dataset = load_dataset("gretelai/synthetic_text_to_sql", split="train")
        
        def format_sample(example):
            prompt = f"Generate SQL for: {example['sql_prompt']}\nSQL:"
            response = example['sql']
            full_text = f"{prompt} {response}{tokenizer.eos_token}"
            return {'text': full_text}
        
        dataset = dataset.map(format_sample, remove_columns=dataset.column_names)
        
    else:
        # Generic dataset
        dataset = load_dataset(dataset_name, split="train")
    
    # Tokenize
    def tokenize_function(examples):
        return tokenizer(
            examples['text'],
            truncation=True,
            max_length=max_length,
            padding=False,
        )
    
    tokenized_dataset = dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=dataset.column_names,
        desc="Tokenizing dataset"
    )
    
    return tokenized_dataset


class GradientTrackingTrainer(Trainer):
    """Custom Trainer that integrates gradient tracking"""
    
    def __init__(self, gradient_tracker=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.gradient_tracker = gradient_tracker
    
    def training_step(self, model, inputs):
        """Override training step to update gradient tracker"""
        loss = super().training_step(model, inputs)
        
        # Update gradient tracker after backward pass
        if self.gradient_tracker is not None:
            self.gradient_tracker.update()
        
        return loss


def main():
    parser = argparse.ArgumentParser(
        description="Fine-tune LLM with QLoRA and track gradients for GASQ"
    )
    
    parser.add_argument(
        "--model_name",
        type=str,
        required=True,
        help="Base model name (e.g., Qwen/Qwen-7B, mistralai/Mistral-7B-v0.1)"
    )
    
    parser.add_argument(
        "--dataset",
        type=str,
        default="sql",
        help="Dataset: 'sql' for text-to-sql or HF dataset name"
    )
    
    parser.add_argument(
        "--output_dir",
        type=str,
        required=True,
        help="Output directory for model and gradient stats"
    )
    
    parser.add_argument(
        "--gradient_stats_dir",
        type=str,
        default=None,
        help="Directory to save gradient statistics (default: output_dir/gradient_stats)"
    )
    
    parser.add_argument(
        "--num_epochs",
        type=int,
        default=3,
        help="Number of training epochs"
    )
    
    parser.add_argument(
        "--batch_size",
        type=int,
        default=4,
        help="Per-device training batch size"
    )
    
    parser.add_argument(
        "--learning_rate",
        type=float,
        default=2e-4,
        help="Learning rate"
    )
    
    parser.add_argument(
        "--lora_r",
        type=int,
        default=16,
        help="LoRA rank"
    )
    
    parser.add_argument(
        "--lora_alpha",
        type=int,
        default=32,
        help="LoRA alpha"
    )
    
    parser.add_argument(
        "--max_length",
        type=int,
        default=512,
        help="Maximum sequence length"
    )
    
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=4,
        help="Gradient accumulation steps"
    )
    
    args = parser.parse_args()
    
    # Set gradient stats directory
    if args.gradient_stats_dir is None:
        args.gradient_stats_dir = f"{args.output_dir}/gradient_stats"
    
    # Load model and tokenizer
    logger.info("Step 1/5: Loading model and tokenizer...")
    model, tokenizer = load_model_and_tokenizer(args.model_name)
    
    # Setup LoRA
    logger.info("Step 2/5: Setting up LoRA...")
    model = setup_lora(model, lora_r=args.lora_r, lora_alpha=args.lora_alpha)
    
    # Load dataset
    logger.info("Step 3/5: Loading and preparing dataset...")
    train_dataset = load_dataset_for_task(
        args.dataset,
        tokenizer,
        max_length=args.max_length
    )
    
    # Initialize gradient tracker
    logger.info("Step 4/5: Initializing gradient tracker...")
    gradient_tracker = GradientStatTracker(
        model,
        save_path=args.gradient_stats_dir,
        save_every_updates=50,
        save_every_seconds=300,
        track_lora_only=True,
        verbose=True
    )
    
    # Training arguments
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.num_epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        fp16=False,
        bf16=True,
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=2,
        optim="paged_adamw_8bit",
        lr_scheduler_type="cosine",
        warmup_ratio=0.05,
        gradient_checkpointing=True,
        report_to="none",
    )
    
    # Data collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )
    
    # Create trainer with gradient tracking
    logger.info("Step 5/5: Starting training with gradient tracking...")
    trainer = GradientTrackingTrainer(
        gradient_tracker=gradient_tracker,
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
    )
    
    # Train
    trainer.train()
    
    # Force save final gradient stats
    logger.info("Training complete. Saving final gradient statistics...")
    gradient_tracker.force_save()
    
    # Save model
    logger.info("Saving fine-tuned model...")
    trainer.save_model()
    tokenizer.save_pretrained(args.output_dir)
    
    # Print gradient statistics summary
    logger.info("=" * 60)
    logger.info("Gradient Statistics Summary:")
    logger.info("=" * 60)
    summary = gradient_tracker.summary()
    
    # Sort by importance
    sorted_layers = sorted(
        summary.items(),
        key=lambda x: x[1]['combined_importance'],
        reverse=True
    )
    
    logger.info(f"Top 10 most important layers:")
    for layer, stats in sorted_layers[:10]:
        logger.info(f"  {layer}: {stats['combined_importance']:.4f}")
    
    logger.info(f"\nGradient stats saved to: {args.gradient_stats_dir}/gradient_stats.json")
    logger.info(f"Model saved to: {args.output_dir}")
    logger.info("\nNext step: Run GASQ quantization with quantize_model.py")


if __name__ == "__main__":
    main()
