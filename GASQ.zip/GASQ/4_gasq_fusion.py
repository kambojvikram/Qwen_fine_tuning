"""
Step 4: GASQ Fusion - Combine All Signals
Fuses gradient statistics, AWQ scores, and GPTQ sensitivity with adaptive weights
"""

import os
import yaml
import json
from typing import Dict, Any, List


def load_config(config_path="configs/gasq_config.yaml"):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def load_json(path: str) -> Dict:
    """Load JSON file."""
    with open(path, 'r') as f:
        return json.load(f)


def identify_layer_type(layer_name: str) -> str:
    """
    Identify layer type from name for adaptive weighting.
    
    Returns one of:
    - attention_q, attention_k, attention_v, attention_o
    - mlp_up, mlp_down, mlp_gate
    - layer_norm
    - embedding
    - lm_head
    - default
    """
    name_lower = layer_name.lower()
    
    if 'q_proj' in name_lower:
        return 'attention_q'
    elif 'k_proj' in name_lower:
        return 'attention_k'
    elif 'v_proj' in name_lower:
        return 'attention_v'
    elif 'o_proj' in name_lower:
        return 'attention_o'
    elif 'gate_proj' in name_lower or 'w1' in name_lower:
        return 'mlp_gate'
    elif 'up_proj' in name_lower or 'w3' in name_lower:
        return 'mlp_up'
    elif 'down_proj' in name_lower or 'w2' in name_lower:
        return 'mlp_down'
    elif 'norm' in name_lower or 'ln' in name_lower:
        return 'layer_norm'
    elif 'embed' in name_lower:
        return 'embedding'
    elif 'lm_head' in name_lower:
        return 'lm_head'
    else:
        return 'default'


def match_layer_names(grad_stats: Dict, awq_stats: Dict, gptq_stats: Dict) -> List[str]:
    """
    Match layer names across all three statistics sources.
    Handles potential naming differences.
    """
    # Get all layer names
    grad_layers = set(k for k in grad_stats.keys() if k != '_metadata')
    awq_layers = set(k for k in awq_stats.keys() if k != '_metadata')
    gptq_layers = set(k for k in gptq_stats.keys() if k != '_metadata')
    
    # Find common layers (exact match)
    common_layers = grad_layers & awq_layers & gptq_layers
    
    print(f"[Layer Matching]")
    print(f"  Gradient stats: {len(grad_layers)} layers")
    print(f"  AWQ stats: {len(awq_layers)} layers")
    print(f"  GPTQ stats: {len(gptq_layers)} layers")
    print(f"  Common layers: {len(common_layers)} layers")
    
    if len(common_layers) < len(grad_layers) * 0.8:
        print("  Warning: Less than 80% layer overlap. Check naming consistency.")
    
    return sorted(list(common_layers))


def normalize_signal(value: float, min_val: float, max_val: float) -> float:
    """Normalize value to [0, 1] range."""
    if max_val - min_val < 1e-8:
        return 0.5
    return (value - min_val) / (max_val - min_val)


def compute_gasq_fusion(
    grad_stats: Dict,
    awq_stats: Dict,
    gptq_stats: Dict,
    config: Dict
) -> Dict[str, Any]:
    """
    Fuse gradient, AWQ, and GPTQ signals using adaptive weights.
    
    Returns:
        Dict mapping layer names to GASQ combined scores
    """
    common_layers = match_layer_names(grad_stats, awq_stats, gptq_stats)
    
    if not common_layers:
        raise ValueError("No common layers found across gradient/AWQ/GPTQ stats!")
    
    # Extract scores for normalization
    grad_scores = [grad_stats[l]['combined_importance'] for l in common_layers]
    awq_scores = [awq_stats[l]['awq_score_normalized'] for l in common_layers]
    gptq_scores = [gptq_stats[l]['gptq_sensitivity_normalized'] for l in common_layers]
    
    # Global min/max for normalization (already normalized, but ensure [0,1])
    grad_min, grad_max = min(grad_scores), max(grad_scores)
    
    print(f"\n[Score Ranges]")
    print(f"  Gradient: [{grad_min:.4f}, {grad_max:.4f}]")
    print(f"  AWQ: [0.0000, 1.0000] (pre-normalized)")
    print(f"  GPTQ: [0.0000, 1.0000] (pre-normalized)")
    
    # Compute GASQ scores
    gasq_results = {}
    
    for layer_name in common_layers:
        # Get raw scores
        grad_score = grad_stats[layer_name]['combined_importance']
        awq_score = awq_stats[layer_name]['awq_score_normalized']
        gptq_score = gptq_stats[layer_name]['gptq_sensitivity_normalized']
        
        # Normalize gradient score to [0, 1]
        grad_norm = normalize_signal(grad_score, grad_min, grad_max)
        
        # Get layer type
        layer_type = identify_layer_type(layer_name)
        
        # Get adaptive weights for this layer type
        weights = config['gasq']['weights'].get(layer_type, config['gasq']['weights']['default'])
        w_grad, w_awq, w_gptq = weights
        
        # Ensure weights sum to 1
        total_weight = w_grad + w_awq + w_gptq
        w_grad /= total_weight
        w_awq /= total_weight
        w_gptq /= total_weight
        
        # Compute GASQ combined score
        gasq_score = (
            w_grad * grad_norm +
            w_awq * awq_score +
            w_gptq * gptq_score
        )
        
        # Store result
        gasq_results[layer_name] = {
            'gasq_score': gasq_score,
            'gradient_score': grad_norm,
            'awq_score': awq_score,
            'gptq_score': gptq_score,
            'layer_type': layer_type,
            'weights': {
                'gradient': w_grad,
                'awq': w_awq,
                'gptq': w_gptq
            },
            'raw_stats': {
                'gradient_importance': grad_score,
                'awq_mean_activation': awq_stats[layer_name].get('mean_activation', 0.0),
                'gptq_trace': gptq_stats[layer_name].get('trace', 0.0)
            }
        }
    
    return gasq_results


def allocate_bits(gasq_results: Dict, config: Dict) -> Dict[str, int]:
    """
    Allocate bit widths based on GASQ scores.
    
    Strategy:
    - High scores (>= high_threshold) → 8-bit
    - Medium scores (>= medium_threshold) → 6-bit
    - Low scores (< medium_threshold) → 4-bit
    
    Adjusts thresholds to meet target_average_bits.
    """
    thresholds = config['gasq']['bit_allocation']
    high_thresh = thresholds['high_precision_threshold']
    med_thresh = thresholds['medium_precision_threshold']
    target_avg = thresholds['target_average_bits']
    
    # Initial allocation
    bit_allocation = {}
    for layer_name, data in gasq_results.items():
        score = data['gasq_score']
        if score >= high_thresh:
            bits = 8
        elif score >= med_thresh:
            bits = 6
        else:
            bits = 4
        bit_allocation[layer_name] = bits
    
    # Check average
    avg_bits = sum(bit_allocation.values()) / len(bit_allocation)
    
    print(f"\n[Bit Allocation - Initial]")
    print(f"  8-bit layers: {sum(1 for b in bit_allocation.values() if b == 8)}")
    print(f"  6-bit layers: {sum(1 for b in bit_allocation.values() if b == 6)}")
    print(f"  4-bit layers: {sum(1 for b in bit_allocation.values() if b == 4)}")
    print(f"  Average: {avg_bits:.2f} bits")
    print(f"  Target: {target_avg:.2f} bits")
    
    # Adjust thresholds if needed to meet target
    if abs(avg_bits - target_avg) > 0.2:
        print(f"  Adjusting thresholds to meet target...")
        
        # Binary search for optimal thresholds
        scores = sorted([d['gasq_score'] for d in gasq_results.values()])
        
        best_high = high_thresh
        best_med = med_thresh
        best_diff = abs(avg_bits - target_avg)
        
        for high_pct in [0.15, 0.20, 0.25, 0.30]:
            for med_pct in [0.50, 0.60, 0.70]:
                high_val = scores[int(len(scores) * (1 - high_pct))]
                med_val = scores[int(len(scores) * (1 - med_pct))]
                
                # Test allocation
                test_bits = []
                for data in gasq_results.values():
                    score = data['gasq_score']
                    if score >= high_val:
                        test_bits.append(8)
                    elif score >= med_val:
                        test_bits.append(6)
                    else:
                        test_bits.append(4)
                
                test_avg = sum(test_bits) / len(test_bits)
                diff = abs(test_avg - target_avg)
                
                if diff < best_diff:
                    best_diff = diff
                    best_high = high_val
                    best_med = med_val
        
        # Apply best thresholds
        for layer_name, data in gasq_results.items():
            score = data['gasq_score']
            if score >= best_high:
                bit_allocation[layer_name] = 8
            elif score >= best_med:
                bit_allocation[layer_name] = 6
            else:
                bit_allocation[layer_name] = 4
        
        avg_bits = sum(bit_allocation.values()) / len(bit_allocation)
        print(f"  Adjusted thresholds: high={best_high:.4f}, med={best_med:.4f}")
        print(f"  New average: {avg_bits:.2f} bits")
    
    return bit_allocation


def main():
    config = load_config()
    
    print("[GASQ Fusion] Step 4: Combining Gradient + AWQ + GPTQ")
    
    # Load all statistics
    print("\n[Loading statistics...]")
    grad_stats = load_json(config['paths']['gradient_stats'])
    awq_stats = load_json(config['paths']['awq_stats'])
    gptq_stats = load_json(config['paths']['gptq_stats'])
    
    # Compute GASQ fusion
    print("\n[Computing GASQ fusion with adaptive weights...]")
    gasq_results = compute_gasq_fusion(grad_stats, awq_stats, gptq_stats, config)
    
    # Allocate bits
    print("\n[Allocating bit widths...]")
    bit_allocation = allocate_bits(gasq_results, config)
    
    # Add bit allocation to results
    for layer_name in gasq_results.keys():
        gasq_results[layer_name]['allocated_bits'] = bit_allocation[layer_name]
    
    # Summary statistics
    print(f"\n[Final Bit Allocation]")
    count_8bit = sum(1 for b in bit_allocation.values() if b == 8)
    count_6bit = sum(1 for b in bit_allocation.values() if b == 6)
    count_4bit = sum(1 for b in bit_allocation.values() if b == 4)
    avg_bits = sum(bit_allocation.values()) / len(bit_allocation)
    
    print(f"  Total layers: {len(bit_allocation)}")
    print(f"  8-bit: {count_8bit} layers ({count_8bit/len(bit_allocation)*100:.1f}%)")
    print(f"  6-bit: {count_6bit} layers ({count_6bit/len(bit_allocation)*100:.1f}%)")
    print(f"  4-bit: {count_4bit} layers ({count_4bit/len(bit_allocation)*100:.1f}%)")
    print(f"  Average: {avg_bits:.2f} bits")
    print(f"  Compression: {16/avg_bits:.2f}x from FP16")
    
    # Show top-10 highest GASQ score layers (will get 8-bit)
    sorted_layers = sorted(
        gasq_results.items(),
        key=lambda x: x[1]['gasq_score'],
        reverse=True
    )
    
    print(f"\n[Top 10 Layers (8-bit candidates)]")
    for i, (name, data) in enumerate(sorted_layers[:10]):
        print(f"  {i+1}. {name}")
        print(f"      GASQ={data['gasq_score']:.4f}, Type={data['layer_type']}, Bits={data['allocated_bits']}")
        print(f"      [G={data['gradient_score']:.3f}, A={data['awq_score']:.3f}, Q={data['gptq_score']:.3f}]")
    
    # Save results
    output_dir = os.path.dirname(config['paths']['gasq_stats'])
    os.makedirs(output_dir, exist_ok=True)
    
    with open(config['paths']['gasq_stats'], 'w') as f:
        json.dump(gasq_results, f, indent=2)
    
    print(f"\n✓ Step 4 Complete: GASQ Fusion")
    print(f"  - Saved to: {config['paths']['gasq_stats']}")
    print("\nNext step: python 5_quantize_model.py")


if __name__ == "__main__":
    main()


"""
Run with:
python 4_gasq_fusion.py
"""
