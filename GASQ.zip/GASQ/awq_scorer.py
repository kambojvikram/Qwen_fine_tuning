"""
AWQ (Activation-aware Weight Quantization) Scorer
Measures which weights have high runtime activation impact
"""

import torch
import torch.nn as nn
from typing import Dict, List
from tqdm import tqdm
import logging

logger = logging.getLogger(__name__)


class AWQScorer:
    """
    Computes AWQ scores for each layer by measuring activation magnitudes
    during calibration data forward passes.
    """
    
    def __init__(self, model: nn.Module, device: str = "cuda"):
        self.model = model
        self.device = device
        self.activation_stats = {}
        self.hooks = []
    
    def _get_activation_hook(self, name: str):
        """Create hook to capture activations"""
        def hook(module, input, output):
            # Only process Linear/Conv layers with weights
            if not hasattr(module, 'weight') or module.weight is None:
                return
            
            # Get input activations
            x = input[0] if isinstance(input, tuple) else input
            
            # Compute per-channel activation magnitudes
            if x.dim() >= 2:
                # Shape: [batch, seq_len, hidden] or [batch, hidden]
                # Average over batch and sequence dimensions
                act_magnitude = x.abs().mean(dim=list(range(x.dim() - 1)))
            else:
                act_magnitude = x.abs()
            
            # Accumulate statistics
            if name not in self.activation_stats:
                self.activation_stats[name] = {
                    'magnitude_sum': torch.zeros_like(act_magnitude),
                    'count': 0
                }
            
            self.activation_stats[name]['magnitude_sum'] += act_magnitude.detach().cpu()
            self.activation_stats[name]['count'] += 1
        
        return hook
    
    def register_hooks(self):
        """Register forward hooks on all Linear layers"""
        for name, module in self.model.named_modules():
            if isinstance(module, (nn.Linear, nn.Conv1d, nn.Conv2d)):
                hook = module.register_forward_hook(self._get_activation_hook(name))
                self.hooks.append(hook)
        
        logger.info(f"Registered AWQ hooks on {len(self.hooks)} layers")
    
    def remove_hooks(self):
        """Remove all hooks"""
        for hook in self.hooks:
            hook.remove()
        self.hooks = []
    
    @torch.no_grad()
    def compute_scores(
        self,
        calibration_dataloader,
        num_batches: int = 128
    ) -> Dict[str, float]:
        """
        Compute AWQ scores using calibration data.
        
        Args:
            calibration_dataloader: DataLoader with calibration samples
            num_batches: Number of batches to use (default 128)
        
        Returns:
            Dictionary mapping layer names to AWQ scores
        """
        self.model.eval()
        self.activation_stats = {}
        self.register_hooks()
        
        logger.info("Computing AWQ scores...")
        
        try:
            for i, batch in enumerate(tqdm(calibration_dataloader, 
                                          desc="AWQ Calibration",
                                          total=num_batches)):
                if i >= num_batches:
                    break
                
                # Move batch to device
                if isinstance(batch, dict):
                    batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                            for k, v in batch.items()}
                    self.model(**batch)
                else:
                    if isinstance(batch, (tuple, list)):
                        batch = tuple(x.to(self.device) if isinstance(x, torch.Tensor) else x 
                                     for x in batch)
                        self.model(*batch)
                    else:
                        batch = batch.to(self.device)
                        self.model(batch)
        
        finally:
            self.remove_hooks()
        
        # Compute final AWQ scores
        awq_scores = {}
        for name, stats in self.activation_stats.items():
            if stats['count'] > 0:
                # Average activation magnitude across all calibration samples
                avg_magnitude = stats['magnitude_sum'] / stats['count']
                # Take mean across channels as final score
                awq_scores[name] = float(avg_magnitude.mean().item())
        
        logger.info(f"Computed AWQ scores for {len(awq_scores)} layers")
        
        # Normalize scores to reasonable range
        if awq_scores:
            max_score = max(awq_scores.values())
            if max_score > 0:
                awq_scores = {k: v / max_score for k, v in awq_scores.items()}
        
        return awq_scores


def compute_awq_scores_simple(
    model: nn.Module,
    calibration_dataloader,
    device: str = "cuda",
    num_batches: int = 128
) -> Dict[str, float]:
    """
    Convenience function to compute AWQ scores.
    
    Args:
        model: The model to analyze
        calibration_dataloader: DataLoader with calibration data
        device: Device to run on
        num_batches: Number of calibration batches
    
    Returns:
        Dictionary mapping layer names to AWQ scores
    """
    scorer = AWQScorer(model, device=device)
    return scorer.compute_scores(calibration_dataloader, num_batches=num_batches)
