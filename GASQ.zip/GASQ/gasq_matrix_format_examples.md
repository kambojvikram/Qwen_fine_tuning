# GASQ Matrix Format Examples - Dummy Data

## Model Architecture: 3-Layer Transformer (Text-to-SQL Fine-tuned)

### Matrix Dimensions Reference
- Embedding layers: [vocab_size=32000, hidden_dim=768]
- Q/K/V projections: [hidden_dim=768, num_heads=12, head_dim=64]
- O projection: [num_heads*head_dim=768, hidden_dim=768]
- MLP up: [hidden_dim=768, intermediate_dim=3072]
- MLP down: [intermediate_dim=3072, hidden_dim=768]
- Layer norms: [hidden_dim=768]
- LM head: [hidden_dim=768, vocab_size=32000]

---

## Layer-by-Layer Matrices

### 1. TOKEN EMBEDDINGS
```
Layer Name: token_embed
Type: embedding
Dimensions: [32000, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.52   │  0.48   │  0.55   │  0.51   │
│  0.49   │  0.53   │  0.50   │  0.54   │
│  0.47   │  0.51   │  0.52   │  0.48   │
│  0.50   │  0.49   │  0.53   │  0.51   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.507

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.45   │  0.48   │  0.42   │  0.46   │
│  0.44   │  0.47   │  0.45   │  0.43   │
│  0.46   │  0.44   │  0.48   │  0.45   │
│  0.43   │  0.46   │  0.44   │  0.47   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.452

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.38   │  0.42   │  0.40   │  0.39   │
│  0.41   │  0.38   │  0.43   │  0.40   │
│  0.39   │  0.41   │  0.38   │  0.42   │
│  0.40   │  0.39   │  0.41   │  0.38   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.399

GASQ Combined Score: 0.40 * 0.507 + 0.30 * 0.452 + 0.30 * 0.399 = 0.458
Bit Allocation: 4-bit
```

---

### 2. POSITION EMBEDDINGS
```
Layer Name: pos_embed
Type: embedding
Dimensions: [2048, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.28   │  0.32   │  0.30   │  0.29   │
│  0.31   │  0.28   │  0.33   │  0.30   │
│  0.29   │  0.31   │  0.28   │  0.32   │
│  0.30   │  0.29   │  0.31   │  0.28   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.299

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.42   │  0.45   │  0.43   │  0.44   │
│  0.43   │  0.42   │  0.46   │  0.43   │
│  0.44   │  0.43   │  0.42   │  0.45   │
│  0.43   │  0.44   │  0.43   │  0.42   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.433

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.35   │  0.38   │  0.36   │  0.37   │
│  0.36   │  0.35   │  0.39   │  0.36   │
│  0.37   │  0.36   │  0.35   │  0.38   │
│  0.36   │  0.37   │  0.36   │  0.35   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.364

GASQ Combined Score: 0.40 * 0.299 + 0.30 * 0.433 + 0.30 * 0.364 = 0.359
Bit Allocation: 4-bit
```

---

### 3. LAYER 1 - PRE-ATTENTION NORM
```
Layer Name: L1_ln1
Type: layer_norm
Dimensions: [768]

Gradient Statistics Vector (sampled):
[0.22, 0.25, 0.23, 0.24, 0.23, 0.25, 0.22, 0.24, ...]
Mean Gradient Norm: 0.235

AWQ Activation Scores Vector (sampled):
[0.48, 0.51, 0.49, 0.50, 0.52, 0.49, 0.51, 0.48, ...]
Mean AWQ Score: 0.497

GPTQ Sensitivity Vector (sampled):
[0.32, 0.35, 0.33, 0.34, 0.32, 0.36, 0.33, 0.34, ...]
Mean GPTQ Sensitivity: 0.336

GASQ Combined Score: 0.40 * 0.235 + 0.30 * 0.497 + 0.30 * 0.336 = 0.344
Bit Allocation: 4-bit
```

---

### 4. LAYER 1 - QUERY PROJECTION (Q)
```
Layer Name: L1_attn_q
Type: attention_q
Dimensions: [768, 768] (reshaped to [768, 12, 64] for multi-head)

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.88   │  0.91   │  0.89   │  0.90   │
│  0.92   │  0.87   │  0.93   │  0.89   │
│  0.89   │  0.91   │  0.88   │  0.92   │
│  0.90   │  0.89   │  0.91   │  0.88   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.896  ← HIGH (learned SQL pattern matching)

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.72   │  0.75   │  0.73   │  0.74   │
│  0.74   │  0.72   │  0.76   │  0.73   │
│  0.73   │  0.74   │  0.72   │  0.75   │
│  0.74   │  0.73   │  0.74   │  0.72   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.735

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.82   │  0.85   │  0.83   │  0.84   │
│  0.84   │  0.82   │  0.86   │  0.83   │
│  0.83   │  0.84   │  0.82   │  0.85   │
│  0.84   │  0.83   │  0.84   │  0.82   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.835

GASQ Combined Score: 0.40 * 0.896 + 0.30 * 0.735 + 0.30 * 0.835 = 0.829
Bit Allocation: 8-bit ← CRITICAL for task performance
```

---

### 5. LAYER 1 - KEY PROJECTION (K)
```
Layer Name: L1_attn_k
Type: attention_k
Dimensions: [768, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.85   │  0.88   │  0.86   │  0.87   │
│  0.89   │  0.84   │  0.90   │  0.86   │
│  0.86   │  0.88   │  0.85   │  0.89   │
│  0.87   │  0.86   │  0.88   │  0.85   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.868

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.70   │  0.73   │  0.71   │  0.72   │
│  0.72   │  0.70   │  0.74   │  0.71   │
│  0.71   │  0.72   │  0.70   │  0.73   │
│  0.72   │  0.71   │  0.72   │  0.70   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.715

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.80   │  0.83   │  0.81   │  0.82   │
│  0.82   │  0.80   │  0.84   │  0.81   │
│  0.81   │  0.82   │  0.80   │  0.83   │
│  0.82   │  0.81   │  0.82   │  0.80   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.815

GASQ Combined Score: 0.40 * 0.868 + 0.30 * 0.715 + 0.30 * 0.815 = 0.806
Bit Allocation: 8-bit
```

---

### 6. LAYER 1 - VALUE PROJECTION (V)
```
Layer Name: L1_attn_v
Type: attention_v
Dimensions: [768, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.83   │  0.86   │  0.84   │  0.85   │
│  0.87   │  0.82   │  0.88   │  0.84   │
│  0.84   │  0.86   │  0.83   │  0.87   │
│  0.85   │  0.84   │  0.86   │  0.83   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.849

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.68   │  0.71   │  0.69   │  0.70   │
│  0.70   │  0.68   │  0.72   │  0.69   │
│  0.69   │  0.70   │  0.68   │  0.71   │
│  0.70   │  0.69   │  0.70   │  0.68   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.695

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.78   │  0.81   │  0.79   │  0.80   │
│  0.80   │  0.78   │  0.82   │  0.79   │
│  0.79   │  0.80   │  0.78   │  0.81   │
│  0.80   │  0.79   │  0.80   │  0.78   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.795

GASQ Combined Score: 0.40 * 0.849 + 0.30 * 0.695 + 0.30 * 0.795 = 0.787
Bit Allocation: 8-bit
```

---

### 7. LAYER 1 - OUTPUT PROJECTION (O)
```
Layer Name: L1_attn_o
Type: attention_o
Dimensions: [768, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.68   │  0.71   │  0.69   │  0.70   │
│  0.72   │  0.67   │  0.73   │  0.69   │
│  0.69   │  0.71   │  0.68   │  0.72   │
│  0.70   │  0.69   │  0.71   │  0.68   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.698

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.65   │  0.68   │  0.66   │  0.67   │
│  0.67   │  0.65   │  0.69   │  0.66   │
│  0.66   │  0.67   │  0.65   │  0.68   │
│  0.67   │  0.66   │  0.67   │  0.65   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.665

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.72   │  0.75   │  0.73   │  0.74   │
│  0.74   │  0.72   │  0.76   │  0.73   │
│  0.73   │  0.74   │  0.72   │  0.75   │
│  0.74   │  0.73   │  0.74   │  0.72   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.735

GASQ Combined Score: 0.40 * 0.698 + 0.30 * 0.665 + 0.30 * 0.735 = 0.699
Bit Allocation: 6-bit
```

---

### 8. LAYER 1 - PRE-MLP NORM
```
Layer Name: L1_ln2
Type: layer_norm
Dimensions: [768]

Gradient Statistics Vector (sampled):
[0.26, 0.29, 0.27, 0.28, 0.27, 0.29, 0.26, 0.28, ...]
Mean Gradient Norm: 0.275

AWQ Activation Scores Vector (sampled):
[0.52, 0.55, 0.53, 0.54, 0.56, 0.53, 0.55, 0.52, ...]
Mean AWQ Score: 0.537

GPTQ Sensitivity Vector (sampled):
[0.38, 0.41, 0.39, 0.40, 0.38, 0.42, 0.39, 0.40, ...]
Mean GPTQ Sensitivity: 0.396

GASQ Combined Score: 0.40 * 0.275 + 0.30 * 0.537 + 0.30 * 0.396 = 0.390
Bit Allocation: 4-bit
```

---

### 9. LAYER 1 - MLP UP PROJECTION
```
Layer Name: L1_mlp_up
Type: mlp_up
Dimensions: [768, 3072]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.62   │  0.65   │  0.63   │  0.64   │
│  0.66   │  0.61   │  0.67   │  0.63   │
│  0.63   │  0.65   │  0.62   │  0.66   │
│  0.64   │  0.63   │  0.65   │  0.62   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.638

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.58   │  0.61   │  0.59   │  0.60   │
│  0.60   │  0.58   │  0.62   │  0.59   │
│  0.59   │  0.60   │  0.58   │  0.61   │
│  0.60   │  0.59   │  0.60   │  0.58   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.595

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.55   │  0.58   │  0.56   │  0.57   │
│  0.57   │  0.55   │  0.59   │  0.56   │
│  0.56   │  0.57   │  0.55   │  0.58   │
│  0.57   │  0.56   │  0.57   │  0.55   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.565

GASQ Combined Score: 0.40 * 0.638 + 0.30 * 0.595 + 0.30 * 0.565 = 0.603
Bit Allocation: 6-bit
```

---

### 10. LAYER 1 - MLP DOWN PROJECTION
```
Layer Name: L1_mlp_down
Type: mlp_down
Dimensions: [3072, 768]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.45   │  0.48   │  0.46   │  0.47   │
│  0.49   │  0.44   │  0.50   │  0.46   │
│  0.46   │  0.48   │  0.45   │  0.49   │
│  0.47   │  0.46   │  0.48   │  0.45   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.468

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.52   │  0.55   │  0.53   │  0.54   │
│  0.54   │  0.52   │  0.56   │  0.53   │
│  0.53   │  0.54   │  0.52   │  0.55   │
│  0.54   │  0.53   │  0.54   │  0.52   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.535

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.48   │  0.51   │  0.49   │  0.50   │
│  0.50   │  0.48   │  0.52   │  0.49   │
│  0.49   │  0.50   │  0.48   │  0.51   │
│  0.50   │  0.49   │  0.50   │  0.48   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.495

GASQ Combined Score: 0.40 * 0.468 + 0.30 * 0.535 + 0.30 * 0.495 = 0.496
Bit Allocation: 4-bit
```

---

### 28. FINAL LAYER NORM
```
Layer Name: final_ln
Type: layer_norm
Dimensions: [768]

Gradient Statistics Vector (sampled):
[0.32, 0.35, 0.33, 0.34, 0.33, 0.35, 0.32, 0.34, ...]
Mean Gradient Norm: 0.335

AWQ Activation Scores Vector (sampled):
[0.62, 0.65, 0.63, 0.64, 0.66, 0.63, 0.65, 0.62, ...]
Mean AWQ Score: 0.637

GPTQ Sensitivity Vector (sampled):
[0.52, 0.55, 0.53, 0.54, 0.52, 0.56, 0.53, 0.54, ...]
Mean GPTQ Sensitivity: 0.536

GASQ Combined Score: 0.40 * 0.335 + 0.30 * 0.637 + 0.30 * 0.536 = 0.486
Bit Allocation: 4-bit
```

---

### 29. LANGUAGE MODEL HEAD
```
Layer Name: lm_head
Type: lm_head
Dimensions: [768, 32000]

Gradient Statistics Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.92   │  0.95   │  0.93   │  0.94   │
│  0.96   │  0.91   │  0.97   │  0.93   │
│  0.93   │  0.95   │  0.92   │  0.96   │
│  0.94   │  0.93   │  0.95   │  0.92   │
└─────────┴─────────┴─────────┴─────────┘
Mean Gradient Norm: 0.938  ← HIGHEST (SQL vocabulary output)

AWQ Activation Scores Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.85   │  0.88   │  0.86   │  0.87   │
│  0.87   │  0.85   │  0.89   │  0.86   │
│  0.86   │  0.87   │  0.85   │  0.88   │
│  0.87   │  0.86   │  0.87   │  0.85   │
└─────────┴─────────┴─────────┴─────────┘
Mean AWQ Score: 0.865

GPTQ Sensitivity Matrix (sampled 4x4):
┌─────────┬─────────┬─────────┬─────────┐
│  0.90   │  0.93   │  0.91   │  0.92   │
│  0.92   │  0.90   │  0.94   │  0.91   │
│  0.91   │  0.92   │  0.90   │  0.93   │
│  0.92   │  0.91   │  0.92   │  0.90   │
└─────────┴─────────┴─────────┴─────────┘
Mean GPTQ Sensitivity: 0.915

GASQ Combined Score: 0.40 * 0.938 + 0.30 * 0.865 + 0.30 * 0.915 = 0.909
Bit Allocation: 8-bit ← CRITICAL for output quality
```

---

## Summary Statistics

### Bit Allocation Distribution:
- **8-bit layers (Critical)**: 6 layers
  - L1_attn_q, L1_attn_k, L1_attn_v
  - L2_attn_q, L2_attn_k, L2_attn_v
  - L3_attn_q, L3_attn_k, L3_attn_v
  - lm_head

- **6-bit layers (Important)**: 8 layers
  - L1_attn_o, L2_attn_o, L3_attn_o
  - L1_mlp_up, L2_mlp_up, L3_mlp_up

- **4-bit layers (Compressible)**: 14 layers
  - token_embed, pos_embed
  - All layer norms (L1_ln1, L1_ln2, L2_ln1, L2_ln2, L3_ln1, L3_ln2, final_ln)
  - All MLP down projections (L1_mlp_down, L2_mlp_down, L3_mlp_down)

### Overall Metrics:
- **Average Bit Width**: 5.2 bits
- **Compression Ratio**: 3.1x (from 16-bit)
- **Estimated Task Performance Retention**: 96.5%
- **Total Parameters**: ~125M
- **Original Size**: 250 MB (16-bit)
- **Quantized Size**: 81 MB (GASQ mixed precision)

### Key Insights:
1. **Attention Q/K/V projections** received highest bit allocation due to high gradient adaptation during SQL fine-tuning
2. **LM Head** preserved at 8-bit for accurate token prediction
3. **Layer norms** compressed to 4-bit as they showed minimal adaptation
4. **MLP down projections** aggressively compressed as they maintained general-purpose features
5. **Embeddings** at 4-bit provide adequate representation with significant space savings

This adaptive quantization preserves task-critical SQL understanding while achieving 3x compression.