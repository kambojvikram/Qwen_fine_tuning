"""
Step 3: Compute GPTQ Sensitivity Scores
Measures mathematical sensitivity to quantization using Hessian approximation
"""

import os
import yaml
import torch
import json
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import pandas as pd
from datasets import Dataset


def load_config(config_path="configs/gasq_config.yaml"):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


class GPTQSensitivityComputer:
    """
    Compute GPTQ-style sensitivity using Hessian approximation.
    Higher scores indicate layers sensitive to quantization errors.
    """
    
    def __init__(self, model, tokenizer, config):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.hessian_stats = {}
        self.hooks = []
    
    def _register_hooks(self):
        """Register hooks to collect activations for Hessian computation."""
        def make_hook(name):
            def hook(module, input, output):
                with torch.no_grad():
                    # Get input activations
                    inp = input[0].detach()
                    
                    # Flatten batch and sequence dimensions
                    if inp.dim() == 3:
                        inp = inp.reshape(-1, inp.size(-1))
                    
                    # Compute outer product approximation of Hessian
                    # H ≈ X^T X (input-input correlation)
                    if name not in self.hessian_stats:
                        self.hessian_stats[name] = {
                            'sum_outer': torch.zeros(inp.size(-1), inp.size(-1), device=inp.device),
                            'count': 0
                        }
                    
                    # Accumulate X^T X
                    stats = self.hessian_stats[name]
                    stats['sum_outer'] += inp.T @ inp
                    stats['count'] += inp.size(0)
            
            return hook
        
        # Register hooks on Linear layers
        for name, module in self.model.named_modules():
            if isinstance(module, torch.nn.Linear):
                handle = module.register_forward_hook(make_hook(name))
                self.hooks.append(handle)
        
        print(f"[GPTQ] Registered hooks on {len(self.hooks)} Linear layers")
    
    def _remove_hooks(self):
        """Remove all hooks."""
        for handle in self.hooks:
            handle.remove()
        self.hooks = []
    
    def compute_sensitivity(self, calibration_dataset):
        """
        Compute GPTQ sensitivity scores.
        
        Args:
            calibration_dataset: Dataset for Hessian approximation
            
        Returns:
            Dict mapping layer names to sensitivity scores
        """
        print(f"[GPTQ] Computing sensitivity on {len(calibration_dataset)} calibration samples")
        
        # Register hooks
        self._register_hooks()
        
        # Run forward passes to collect Hessian information
        self.model.eval()
        
        with torch.no_grad():
            for i, sample in enumerate(tqdm(calibration_dataset, desc="GPTQ Calibration")):
                inputs = self.tokenizer(
                    sample['text'],
                    return_tensors='pt',
                    truncation=True,
                    max_length=self.config['training']['max_seq_length']
                ).to(self.model.device)
                
                # Forward pass
                _ = self.model(**inputs)
                
                if i >= self.config['gptq']['calibration_samples'] - 1:
                    break
        
        # Compute sensitivity scores from Hessian
        sensitivity_scores = {}
        
        for name, stats in self.hessian_stats.items():
            if stats['count'] == 0:
                continue
            
            # Average Hessian approximation
            H = stats['sum_outer'] / stats['count']
            
            # Move to CPU for computation
            H_cpu = H.cpu()
            
            # Compute eigenvalues (measure of curvature)
            try:
                eigenvalues = torch.linalg.eigvalsh(H_cpu)
                
                # Sensitivity metrics
                max_eigenvalue = eigenvalues.max().item()
                mean_eigenvalue = eigenvalues.mean().item()
                trace = eigenvalues.sum().item()
                condition_number = (eigenvalues.max() / (eigenvalues.min() + 1e-8)).item()
                
                # GPTQ sensitivity score
                # Higher trace = more sensitive to weight perturbations
                # Higher condition number = ill-conditioned, needs precision
                sensitivity_score = torch.log1p(torch.tensor(trace)).item() * (1 + torch.log1p(torch.tensor(condition_number)).item())
                
                sensitivity_scores[name] = {
                    'gptq_sensitivity': sensitivity_score,
                    'max_eigenvalue': max_eigenvalue,
                    'mean_eigenvalue': mean_eigenvalue,
                    'trace': trace,
                    'condition_number': condition_number,
                    'calibration_samples': stats['count']
                }
            
            except Exception as e:
                print(f"[GPTQ] Warning: Could not compute eigenvalues for {name}: {e}")
                # Fallback: use Frobenius norm
                sensitivity_score = torch.norm(H_cpu, p='fro').item()
                sensitivity_scores[name] = {
                    'gptq_sensitivity': sensitivity_score,
                    'max_eigenvalue': 0.0,
                    'mean_eigenvalue': 0.0,
                    'trace': 0.0,
                    'condition_number': 1.0,
                    'calibration_samples': stats['count']
                }
        
        # Remove hooks
        self._remove_hooks()
        
        # Clear CUDA cache
        torch.cuda.empty_cache()
        
        print(f"[GPTQ] Computed sensitivity for {len(sensitivity_scores)} layers")
        return sensitivity_scores


def normalize_scores(scores_dict):
    """Normalize GPTQ sensitivity scores to [0, 1] range."""
    all_scores = [v['gptq_sensitivity'] for v in scores_dict.values()]
    min_score = min(all_scores)
    max_score = max(all_scores)
    
    normalized = {}
    for name, data in scores_dict.items():
        normalized[name] = {
            **data,
            'gptq_sensitivity_normalized': (data['gptq_sensitivity'] - min_score) / (max_score - min_score + 1e-8)
        }
    
    return normalized


def main():
    config = load_config()
    
    print("[GPTQ] Step 3: Computing GPTQ Sensitivity")
    print(f"Model: {config['model']['name']}")
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        config['model']['name'],
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # Load fine-tuned model
    print("[Loading fine-tuned model...]")
    base_model = AutoModelForCausalLM.from_pretrained(
        config['model']['name'],
        torch_dtype=torch.float32,  # Use FP32 for accurate Hessian computation
        device_map="auto",
        trust_remote_code=True,
    )
    
    # Load and merge LoRA
    model = PeftModel.from_pretrained(
        base_model,
        config['training']['output_dir'],
        torch_dtype=torch.float32
    )
    model = model.merge_and_unload()
    model.eval()
    
    print(f"[Model loaded in FP32 for Hessian computation]")
    
    # Load calibration dataset
    print("[Loading calibration dataset...]")
    df = pd.read_parquet(
        f"hf://datasets/{config['dataset']['name']}/{config['dataset']['test_split']}.snappy.parquet"
    )
    
    calibration_dataset = Dataset.from_pandas(df)
    
    # Format dataset
    from train_with_gradient_tracking import format_for_sft
    calibration_dataset = calibration_dataset.map(format_for_sft)
    
    def create_conversation(row):
        return {
            "text": (
                f"<|im_start|>system\n{row['system']}<|im_end|>\n"
                f"<|im_start|>user\n{row['user']}<|im_end|>\n"
                f"<|im_start|>assistant\n{row['assistant']}<|im_end|>"
            )
        }
    
    calibration_dataset = calibration_dataset.map(create_conversation)
    
    # Limit to calibration samples
    n_samples = min(len(calibration_dataset), config['gptq']['calibration_samples'])
    calibration_dataset = calibration_dataset.select(range(n_samples))
    
    print(f"[Using {len(calibration_dataset)} calibration samples]")
    
    # Compute GPTQ sensitivity
    gptq_computer = GPTQSensitivityComputer(model, tokenizer, config)
    gptq_scores = gptq_computer.compute_sensitivity(calibration_dataset)
    
    # Normalize scores
    gptq_scores = normalize_scores(gptq_scores)
    
    # Save results
    output_dir = os.path.dirname(config['paths']['gptq_stats'])
    os.makedirs(output_dir, exist_ok=True)
    
    with open(config['paths']['gptq_stats'], 'w') as f:
        json.dump(gptq_scores, f, indent=2)
    
    # Print summary statistics
    normalized_scores = [v['gptq_sensitivity_normalized'] for v in gptq_scores.values()]
    print(f"\n[GPTQ Sensitivity Statistics]")
    print(f"  Layers analyzed: {len(gptq_scores)}")
    print(f"  Mean sensitivity: {sum(normalized_scores) / len(normalized_scores):.4f}")
    print(f"  Min sensitivity: {min(normalized_scores):.4f}")
    print(f"  Max sensitivity: {max(normalized_scores):.4f}")
    
    # Show top-10 most sensitive layers
    sorted_layers = sorted(
        gptq_scores.items(),
        key=lambda x: x[1]['gptq_sensitivity_normalized'],
        reverse=True
    )
    
    print(f"\n[Top 10 Most Sensitive Layers]")
    for i, (name, data) in enumerate(sorted_layers[:10]):
        print(f"  {i+1}. {name}: {data['gptq_sensitivity_normalized']:.4f} (cond={data['condition_number']:.2f})")
    
    print(f"\n✓ Step 3 Complete: GPTQ Sensitivity")
    print(f"  - Saved to: {config['paths']['gptq_stats']}")
    print("\nNext step: python 4_gasq_fusion.py")


if __name__ == "__main__":
    main()


"""
Run with:
python 3_compute_gptq_sensitivity.py

Note: This uses FP32 for accurate Hessian computation.
Requires more GPU memory than previous steps.
"""
