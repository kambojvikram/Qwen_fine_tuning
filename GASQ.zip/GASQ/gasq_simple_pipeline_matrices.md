# GASQ Simple Pipeline - Matrix Format Example

## Single-Head Transformer Flow
**Input → Tokenization → Embedding → MHA (Q, K, V, O) → MLP/FFN → Layer Norm → LM Head → Output**

---

## Example: Text-to-SQL Query
**Input:** "SELECT * FROM users WHERE age > 25"

---

### Stage 1: INPUT TEXT
```
Raw Input: "SELECT * FROM users WHERE age > 25"
Type: Raw string
No quantization needed
```

---

### Stage 2: TOKENIZATION
```
Tokens: ["SELECT", "*", "FROM", "users", "WHERE", "age", ">", "25"]
Token IDs: [2134, 334, 4761, 3667, 5401, 1242, 876, 1653]
Type: Integer array
No quantization needed
```

---

### Stage 3: TOKEN EMBEDDING
```
Layer: token_embed
Dimensions: [vocab_size=32000, hidden_dim=768]
Type: Weight matrix

Sample 4x4 Matrix Representation:

Gradient Statistics (Fine-tuning Adaptation):
┌──────┬──────┬──────┬──────┐
│ 0.51 │ 0.52 │ 0.50 │ 0.51 │
│ 0.50 │ 0.51 │ 0.52 │ 0.51 │
│ 0.52 │ 0.50 │ 0.51 │ 0.50 │
│ 0.51 │ 0.52 │ 0.50 │ 0.52 │
└──────┴──────┴──────┴──────┘
Mean: 0.510 (Moderate adaptation - learned SQL vocabulary)

AWQ Activation Scores (Runtime Importance):
┌──────┬──────┬──────┬──────┐
│ 0.45 │ 0.46 │ 0.44 │ 0.45 │
│ 0.44 │ 0.45 │ 0.46 │ 0.45 │
│ 0.46 │ 0.44 │ 0.45 │ 0.44 │
│ 0.45 │ 0.46 │ 0.44 │ 0.46 │
└──────┴──────┴──────┴──────┘
Mean: 0.450

GPTQ Sensitivity (Quantization Robustness):
┌──────┬──────┬──────┬──────┐
│ 0.42 │ 0.43 │ 0.41 │ 0.42 │
│ 0.41 │ 0.42 │ 0.43 │ 0.42 │
│ 0.43 │ 0.41 │ 0.42 │ 0.41 │
│ 0.42 │ 0.43 │ 0.41 │ 0.43 │
└──────┴──────┴──────┴──────┘
Mean: 0.420

GASQ Combined Score:
= 0.40 × 0.510 + 0.30 × 0.450 + 0.30 × 0.420
= 0.204 + 0.135 + 0.126
= 0.465

Bit Allocation: 4-bit ✓
Reason: Embeddings adapted moderately but remain compressible
```

---

### Stage 4: MULTI-HEAD ATTENTION - QUERY (Q)
```
Layer: mha_query
Dimensions: [hidden_dim=768, hidden_dim=768]
Type: Weight matrix (projects hidden states to query space)

Sample 4x4 Matrix Representation:

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.89 │ 0.90 │ 0.88 │ 0.89 │
│ 0.88 │ 0.89 │ 0.90 │ 0.89 │
│ 0.90 │ 0.88 │ 0.89 │ 0.88 │
│ 0.89 │ 0.90 │ 0.88 │ 0.90 │
└──────┴──────┴──────┴──────┘
Mean: 0.890 (VERY HIGH - learned SQL pattern matching)

AWQ Activation Scores:
┌──────┬──────┬──────┬──────┐
│ 0.74 │ 0.75 │ 0.73 │ 0.74 │
│ 0.73 │ 0.74 │ 0.75 │ 0.74 │
│ 0.75 │ 0.73 │ 0.74 │ 0.73 │
│ 0.74 │ 0.75 │ 0.73 │ 0.75 │
└──────┴──────┴──────┴──────┘
Mean: 0.740

GPTQ Sensitivity:
┌──────┬──────┬──────┬──────┐
│ 0.83 │ 0.84 │ 0.82 │ 0.83 │
│ 0.82 │ 0.83 │ 0.84 │ 0.83 │
│ 0.84 │ 0.82 │ 0.83 │ 0.82 │
│ 0.83 │ 0.84 │ 0.82 │ 0.84 │
└──────┴──────┴──────┴──────┘
Mean: 0.830

GASQ Combined Score:
= 0.40 × 0.890 + 0.30 × 0.740 + 0.30 × 0.830
= 0.356 + 0.222 + 0.249
= 0.827

Bit Allocation: 8-bit ✓✓✓ CRITICAL
Reason: High gradient adaptation for SQL query pattern matching
```

---

### Stage 5: MULTI-HEAD ATTENTION - KEY (K)
```
Layer: mha_key
Dimensions: [768, 768]

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.87 │ 0.88 │ 0.86 │ 0.87 │
│ 0.86 │ 0.87 │ 0.88 │ 0.87 │
│ 0.88 │ 0.86 │ 0.87 │ 0.86 │
│ 0.87 │ 0.88 │ 0.86 │ 0.88 │
└──────┴──────┴──────┴──────┘
Mean: 0.870

AWQ: 0.710 | GPTQ: 0.820

GASQ Score: 0.806 → 8-bit ✓✓✓
```

---

### Stage 6: MULTI-HEAD ATTENTION - VALUE (V)
```
Layer: mha_value
Dimensions: [768, 768]

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.85 │ 0.86 │ 0.84 │ 0.85 │
│ 0.84 │ 0.85 │ 0.86 │ 0.85 │
│ 0.86 │ 0.84 │ 0.85 │ 0.84 │
│ 0.85 │ 0.86 │ 0.84 │ 0.86 │
└──────┴──────┴──────┴──────┘
Mean: 0.850

AWQ: 0.690 | GPTQ: 0.790

GASQ Score: 0.787 → 8-bit ✓✓✓
```

---

### Stage 7: MULTI-HEAD ATTENTION - OUTPUT (O)
```
Layer: mha_output
Dimensions: [768, 768]

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.70 │ 0.71 │ 0.69 │ 0.70 │
│ 0.69 │ 0.70 │ 0.71 │ 0.70 │
│ 0.71 │ 0.69 │ 0.70 │ 0.69 │
│ 0.70 │ 0.71 │ 0.69 │ 0.71 │
└──────┴──────┴──────┴──────┘
Mean: 0.700

AWQ: 0.670 | GPTQ: 0.740

GASQ Score: 0.699 → 6-bit ✓✓
Reason: Important but less critical than Q/K/V projections
```

---

### Stage 8: LAYER NORM 1
```
Layer: layer_norm_1
Dimensions: [768] (single vector of scaling parameters)

Gradient Statistics (sample):
[0.24, 0.25, 0.23, 0.24, 0.25, 0.23, 0.24, 0.25, ...]
Mean: 0.240 (LOW - minimal adaptation)

AWQ: 0.500 | GPTQ: 0.340

GASQ Score: 0.344 → 4-bit ✓
Reason: Normalization layers change very little during fine-tuning
```

---

### Stage 9: MLP/FFN - UP PROJECTION
```
Layer: mlp_up
Dimensions: [768, 3072]
Type: Expands to intermediate dimension

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.64 │ 0.65 │ 0.63 │ 0.64 │
│ 0.63 │ 0.64 │ 0.65 │ 0.64 │
│ 0.65 │ 0.63 │ 0.64 │ 0.63 │
│ 0.64 │ 0.65 │ 0.63 │ 0.65 │
└──────┴──────┴──────┴──────┘
Mean: 0.640

AWQ: 0.600 | GPTQ: 0.570

GASQ Score: 0.603 → 6-bit ✓✓
Reason: Moderate adaptation for domain-specific reasoning
```

---

### Stage 10: MLP/FFN - DOWN PROJECTION
```
Layer: mlp_down
Dimensions: [3072, 768]
Type: Projects back to hidden dimension

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.47 │ 0.48 │ 0.46 │ 0.47 │
│ 0.46 │ 0.47 │ 0.48 │ 0.47 │
│ 0.48 │ 0.46 │ 0.47 │ 0.46 │
│ 0.47 │ 0.48 │ 0.46 │ 0.48 │
└──────┴──────┴──────┴──────┘
Mean: 0.470

AWQ: 0.540 | GPTQ: 0.500

GASQ Score: 0.503 → 4-bit ✓
Reason: General-purpose features, less task-specific
```

---

### Stage 11: LAYER NORM 2
```
Layer: layer_norm_2
Dimensions: [768]

Gradient Statistics (sample):
[0.28, 0.29, 0.27, 0.28, 0.29, 0.27, 0.28, 0.29, ...]
Mean: 0.280

AWQ: 0.540 | GPTQ: 0.400

GASQ Score: 0.394 → 4-bit ✓
```

---

### Stage 12: LANGUAGE MODEL HEAD
```
Layer: lm_head
Dimensions: [768, 32000]
Type: Projects to vocabulary for token prediction

Gradient Statistics:
┌──────┬──────┬──────┬──────┐
│ 0.94 │ 0.95 │ 0.93 │ 0.94 │
│ 0.93 │ 0.94 │ 0.95 │ 0.94 │
│ 0.95 │ 0.93 │ 0.94 │ 0.93 │
│ 0.94 │ 0.95 │ 0.93 │ 0.95 │
└──────┴──────┴──────┴──────┘
Mean: 0.940 (HIGHEST - critical for SQL token generation)

AWQ: 0.870 | GPTQ: 0.920

GASQ Score: 0.909 → 8-bit ✓✓✓ CRITICAL
Reason: Must accurately predict SQL tokens
```

---

### Stage 13: OUTPUT
```
Predicted Token: "SELECT" (token_id: 2134)
Probability: 0.92
Type: Integer output
No quantization needed
```

---

## Summary Statistics

### Bit Allocation by Layer Type:

**8-bit Layers (Critical for Task):**
- MHA Query (Q) - 0.827
- MHA Key (K) - 0.806  
- MHA Value (V) - 0.787
- Language Model Head - 0.909

**6-bit Layers (Important):**
- MHA Output (O) - 0.699
- MLP Up Projection - 0.603

**4-bit Layers (Compressible):**
- Token Embedding - 0.465
- Layer Norm 1 - 0.344
- MLP Down Projection - 0.503
- Layer Norm 2 - 0.394

### Overall Compression:
- **Total Quantized Layers**: 10
- **Average Bit Width**: 5.3 bits
- **Compression Ratio**: 3.0x (from 16-bit baseline)
- **Estimated Task Performance**: 96%
- **Memory Savings**: 67% reduction

### Key Insights:
1. **Attention mechanisms** (Q/K/V) preserved at 8-bit due to high gradient activity during SQL fine-tuning
2. **LM Head** kept at 8-bit to ensure accurate SQL token generation
3. **Normalization layers** compressed to 4-bit as they adapt minimally
4. **MLP layers** show mixed compression - up projection more important than down
5. **Embeddings** safe at 4-bit with moderate quality preservation

This adaptive strategy maintains SQL generation quality while achieving 3x compression!