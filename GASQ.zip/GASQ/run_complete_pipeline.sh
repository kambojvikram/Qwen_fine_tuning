#!/bin/bash
# GASQ Complete Pipeline Example
# End-to-end workflow for quantizing a 7B model with GASQ

set -e  # Exit on error

echo "=========================================="
echo "GASQ Quantization Pipeline"
echo "=========================================="
echo ""

# Configuration
MODEL_NAME="Qwen/Qwen-7B"  # Change to your model
TASK="sql"                 # Change to your task
OUTPUT_BASE="./outputs"
EXPERIMENT_NAME="qwen7b-sql-gasq"

# Directories
TRAIN_OUTPUT="$OUTPUT_BASE/$EXPERIMENT_NAME-finetuned"
QUANT_OUTPUT="$OUTPUT_BASE/$EXPERIMENT_NAME-quantized"
GRADIENT_STATS="$TRAIN_OUTPUT/gradient_stats/gradient_stats.json"

echo "Configuration:"
echo "  Model: $MODEL_NAME"
echo "  Task: $TASK"
echo "  Output: $OUTPUT_BASE/$EXPERIMENT_NAME-*"
echo ""

# Step 1: Fine-tune with gradient tracking
echo "=========================================="
echo "STEP 1/3: Fine-tuning with Gradient Tracking"
echo "=========================================="
echo "This will take approximately 6-8 hours on A100..."
echo ""

python train_with_tracking.py \
    --model_name "$MODEL_NAME" \
    --dataset "$TASK" \
    --output_dir "$TRAIN_OUTPUT" \
    --num_epochs 3 \
    --batch_size 4 \
    --gradient_accumulation_steps 4 \
    --learning_rate 2e-4 \
    --lora_r 16 \
    --lora_alpha 32 \
    --max_length 512

echo ""
echo "✓ Fine-tuning complete!"
echo "  Model saved to: $TRAIN_OUTPUT"
echo "  Gradient stats: $GRADIENT_STATS"
echo ""

# Step 2: Baseline uniform 4-bit quantization
echo "=========================================="
echo "STEP 2/3: Baseline Uniform 4-bit Quantization"
echo "=========================================="
echo "Establishing baseline performance..."
echo ""

BASELINE_OUTPUT="$OUTPUT_BASE/$EXPERIMENT_NAME-baseline-4bit"

python -c "
from transformers import AutoModelForCausalLM, AutoTokenizer
from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
from datasets import load_dataset
import torch

print('Loading model for baseline quantization...')
model_name = '$TRAIN_OUTPUT'
quantize_config = BaseQuantizeConfig(
    bits=4,
    group_size=128,
    desc_act=True,
)

model = AutoGPTQForCausalLM.from_pretrained(
    model_name,
    quantize_config=quantize_config,
)

# Simple calibration
tokenizer = AutoTokenizer.from_pretrained(model_name)
dataset = load_dataset('gretelai/synthetic_text_to_sql', split='train')
calibration = []
for i, example in enumerate(dataset.select(range(128))):
    text = f\"Question: {example['sql_prompt']}\nSQL: {example['sql']}\"
    tokens = tokenizer(text, return_tensors='pt', max_length=512, truncation=True)
    calibration.append({'input_ids': tokens['input_ids'], 'attention_mask': tokens['attention_mask']})

print('Quantizing to uniform 4-bit...')
model.quantize(calibration)

print('Saving baseline model...')
model.save_quantized('$BASELINE_OUTPUT')
tokenizer.save_pretrained('$BASELINE_OUTPUT')
print('✓ Baseline quantization complete!')
"

echo ""
echo "✓ Baseline saved to: $BASELINE_OUTPUT"
echo ""

# Step 3: GASQ quantization
echo "=========================================="
echo "STEP 3/3: GASQ Adaptive Quantization"
echo "=========================================="
echo "This will take approximately 2-3 hours on A100..."
echo ""

python quantize_model.py \
    --model_name "$TRAIN_OUTPUT" \
    --gradient_stats "$GRADIENT_STATS" \
    --output_dir "$QUANT_OUTPUT" \
    --calibration_dataset "$TASK" \
    --target_bits 4.0 \
    --num_calibration_samples 512

echo ""
echo "✓ GASQ quantization complete!"
echo "  Quantized model: $QUANT_OUTPUT/quantized_model"
echo "  GASQ report: $QUANT_OUTPUT/gasq_report.json"
echo ""

# Step 4: Summary
echo "=========================================="
echo "PIPELINE COMPLETE!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Review GASQ report: $QUANT_OUTPUT/gasq_report.json"
echo "2. Compare baseline vs GASQ on your test set"
echo "3. If GASQ provides >3% accuracy gain, deploy it!"
echo ""
echo "Quick comparison:"
echo "  Baseline (4-bit):  $BASELINE_OUTPUT"
echo "  GASQ (mixed):      $QUANT_OUTPUT/quantized_model"
echo ""
echo "To load and test the quantized model:"
echo ""
echo "  from transformers import AutoModelForCausalLM, AutoTokenizer"
echo "  model = AutoModelForCausalLM.from_pretrained('$QUANT_OUTPUT/quantized_model')"
echo "  tokenizer = AutoTokenizer.from_pretrained('$QUANT_OUTPUT/quantized_model')"
echo ""
echo "Happy quantizing! 🚀"
