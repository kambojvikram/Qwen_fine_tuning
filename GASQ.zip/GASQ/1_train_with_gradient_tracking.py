"""
Step 1: Fine-tune model with QLoRA + Gradient Tracking
Trains model on text-to-SQL while collecting gradient statistics
"""

import os
import yaml
import torch
import pandas as pd
from datasets import Dataset, load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer
import sys
sys.path.append(os.path.dirname(__file__))
from utils.gradient_tracker import GradientStatTracker, merge_distributed_stats


def load_config(config_path="configs/gasq_config.yaml"):
    """Load configuration from YAML file."""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def format_for_sft(row):
    """
    Transform raw SQL dataset row into system/user/assistant format.
    Based on user's existing format_for_sft function.
    """
    system_prompt = (
        f"You are a SQL expert assistant specializing in {row['domain']}. "
        f"{row['domain_description']}"
    )
    
    user_query = (
        f"{row['sql_prompt']}\n\n"
        f"Database Schema:\n{row['sql_context']}\n\n"
        f"Task Type: {row['sql_task_type']} - {row['sql_task_type_description']}\n"
        f"Complexity: {row['sql_complexity']} - {row['sql_complexity_description']}\n"
    )
    
    response = f"{row['sql']}"
    
    return {
        "system": system_prompt,
        "user": user_query,
        "assistant": response
    }


def load_and_prepare_dataset(config):
    """Load and prepare text-to-SQL dataset."""
    print(f"Loading dataset: {config['dataset']['name']}")
    
    # Load from Hugging Face
    df = pd.read_parquet(f"hf://datasets/{config['dataset']['name']}/{config['dataset']['train_split']}.snappy.parquet")
    
    # Required fields for SQL
    required_sql_fields = [
        'domain', 'domain_description', 'sql_prompt', 'sql_context',
        'sql_task_type', 'sql_task_type_description', 'sql_complexity',
        'sql_complexity_description', 'sql', 'sql_explanation'
    ]
    
    # Drop rows missing critical fields
    df = df.dropna(subset=required_sql_fields)
    df = df.drop(columns=['__index_level_0__'], errors='ignore')
    
    # Create dataset
    dataset = Dataset.from_pandas(df)
    
    # Map to system/user/assistant format
    dataset = dataset.map(format_for_sft)
    
    # Create conversation format
    def create_conversation(row):
        return {
            "text": (
                f"<|im_start|>system\n{row['system']}<|im_end|>\n"
                f"<|im_start|>user\n{row['user']}<|im_end|>\n"
                f"<|im_start|>assistant\n{row['assistant']}<|im_end|>"
            )
        }
    
    dataset = dataset.map(create_conversation)
    
    # Limit samples if specified
    if config['dataset']['max_samples'] is not None:
        dataset = dataset.select(range(min(len(dataset), config['dataset']['max_samples'])))
    
    print(f"Prepared {len(dataset)} training samples")
    return dataset


def main():
    # Load configuration
    config = load_config()
    
    # Determine device and distributed setup
    local_rank = int(os.environ.get("LOCAL_RANK", -1))
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    is_distributed = world_size > 1
    
    print(f"[Rank {local_rank}] Starting GASQ Step 1: Training + Gradient Tracking")
    print(f"Model: {config['model']['name']}")
    print(f"Distributed: {is_distributed} (world_size={world_size})")
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        config['model']['name'],
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # Load model with 4-bit quantization for QLoRA
    print("[Loading model with 4-bit quantization...]")
    model = AutoModelForCausalLM.from_pretrained(
        config['model']['name'],
        load_in_4bit=config['model']['load_in_4bit'],
        torch_dtype=torch.bfloat16 if config['training']['bf16'] else torch.float16,
        device_map={"": f"cuda:{local_rank}"} if is_distributed else "auto",
        trust_remote_code=True,
    )
    
    # Prepare model for k-bit training
    model = prepare_model_for_kbit_training(model)
    
    # LoRA configuration
    lora_config = LoraConfig(
        r=config['lora']['r'],
        lora_alpha=config['lora']['lora_alpha'],
        lora_dropout=config['lora']['lora_dropout'],
        target_modules=config['lora']['target_modules'],
        bias=config['lora']['bias'],
        task_type=config['lora']['task_type'],
    )
    
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Initialize gradient tracker
    if config['gradient_tracking']['enabled']:
        save_dir = config['gradient_tracking']['save_dir']
        if is_distributed:
            save_dir = os.path.join(save_dir, f"rank_{local_rank}")
        
        tracker = GradientStatTracker(
            model=model,
            save_dir=save_dir,
            ema_fast_decay=config['gradient_tracking']['ema_fast_decay'],
            ema_slow_decay=config['gradient_tracking']['ema_slow_decay'],
            save_every_updates=config['gradient_tracking']['save_every_updates'],
            save_every_seconds=config['gradient_tracking']['save_every_seconds'],
        )
        print(f"[Gradient Tracker] Initialized for rank {local_rank}")
    
    # Load dataset
    train_dataset = load_and_prepare_dataset(config)
    
    # Training arguments
    training_args = TrainingArguments(
        output_dir=config['training']['output_dir'],
        num_train_epochs=config['training']['num_train_epochs'],
        per_device_train_batch_size=config['training']['per_device_train_batch_size'],
        gradient_accumulation_steps=config['training']['gradient_accumulation_steps'],
        learning_rate=config['training']['learning_rate'],
        max_grad_norm=config['training']['max_grad_norm'],
        warmup_ratio=config['training']['warmup_ratio'],
        lr_scheduler_type=config['training']['lr_scheduler_type'],
        logging_steps=config['training']['logging_steps'],
        save_steps=config['training']['save_steps'],
        bf16=config['training']['bf16'],
        optim=config['training']['optim'],
        logging_dir=f"{config['training']['output_dir']}/logs",
        report_to="none",
        ddp_find_unused_parameters=False if is_distributed else None,
        local_rank=local_rank,
    )
    
    # Custom callback for gradient tracking
    class GradientTrackingCallback:
        def __init__(self, tracker):
            self.tracker = tracker
        
        def on_step_end(self, args, state, control, **kwargs):
            # Save stats periodically
            self.tracker.maybe_save_async()
        
        def on_train_end(self, args, state, control, **kwargs):
            # Force save at end
            self.tracker.force_save()
            print(f"\n[Gradient Tracker] Final statistics:")
            print(self.tracker.summary())
    
    # Trainer
    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        dataset_text_field="text",
        max_seq_length=config['training']['max_seq_length'],
        tokenizer=tokenizer,
        callbacks=[GradientTrackingCallback(tracker)] if config['gradient_tracking']['enabled'] else [],
    )
    
    # Train
    print("\n[Starting training...]")
    trainer.train()
    
    # Save fine-tuned model
    print("\n[Saving fine-tuned model...]")
    trainer.save_model()
    tokenizer.save_pretrained(config['training']['output_dir'])
    
    # Final gradient stats save
    if config['gradient_tracking']['enabled']:
        tracker.force_save()
        print(f"[Gradient Stats] Saved to {save_dir}")
    
    # Merge stats from all ranks (only on rank 0)
    if is_distributed and local_rank == 0:
        print("\n[Merging gradient stats from all ranks...]")
        merged_path = merge_distributed_stats(
            save_dir=config['gradient_tracking']['save_dir'],
            world_size=world_size,
            output_name="merged_stats.json"
        )
        print(f"[Merged stats saved to: {merged_path}]")
    
    print("\n✓ Step 1 Complete: Training + Gradient Tracking")
    print(f"  - Model saved to: {config['training']['output_dir']}")
    print(f"  - Gradient stats: {config['paths']['gradient_stats']}")
    print("\nNext step: python 2_compute_awq_scores.py")


if __name__ == "__main__":
    main()


"""
Run with:
# Single GPU
python 1_train_with_gradient_tracking.py

# Multi-GPU with torchrun
torchrun --nproc_per_node=4 1_train_with_gradient_tracking.py
"""
