# GASQ Quantization - Quick Guide (Already Have Gradient Stats)

You already tracked gradients during fine-tuning. Now just run quantization!

---

## What You Need

✅ Your fine-tuned model (directory)  
✅ `gradient_stats.json` file (from your gradient tracking)  
✅ This GASQ quantization package

---

## Quick Start (5 Minutes Setup)

### Step 1: Edit Configuration

Open `quantize_only.sh` and set your paths:

```bash
MODEL_PATH="./your-finetuned-model"              # Your model directory
GRADIENT_STATS="./gradient_stats/stats.json"     # Your gradient stats file
OUTPUT_DIR="./model-quantized"                   # Output directory
```

### Step 2: Run Quantization

```bash
chmod +x quantize_only.sh
./quantize_only.sh
```

That's it! Wait 2-3 hours and you'll have your quantized model.

---

## Manual Command (Alternative)

If you prefer to run the command directly:

```bash
python quantize_model.py \
    --model_name "./your-finetuned-model" \
    --gradient_stats "./gradient_stats.json" \
    --output_dir "./model-quantized" \
    --calibration_dataset "sql" \
    --target_bits 4.0 \
    --num_calibration_samples 512
```

**Parameters:**
- `--model_name`: Path to your fine-tuned model
- `--gradient_stats`: Path to your gradient statistics JSON
- `--output_dir`: Where to save quantized model
- `--calibration_dataset`: Dataset for AWQ/GPTQ calibration
  - Use `"sql"` for text-to-SQL models
  - Use `"wikitext"` for general models
  - Use any HuggingFace dataset name
- `--target_bits`: Average bit width (4.0 = 3.5 GB for 7B model)

---

## What Happens During Quantization

```
1. Load your fine-tuned model
2. Load gradient_stats.json (your tracked gradients)
3. Compute AWQ scores (activation importance)       [30 min]
4. Compute GPTQ scores (quantization sensitivity)    [45 min]
5. Combine all 3 signals with adaptive weights       [5 min]
6. Allocate bits per layer (8/6/4 bit mixed)         [1 min]
7. Apply quantization and save model                 [60 min]

Total: ~2.5 hours on A100
```

---

## Understanding Your gradient_stats.json

Your file should look like this:

```json
{
  "model.layers.0.self_attn.q_proj": {
    "combined_importance": 0.892,
    "update_count": 1500,
    "lora_A_stats": {
      "ema_fast": 0.12,
      "ema_slow": 0.89,
      "variance": 0.023,
      ...
    }
  },
  "model.layers.0.mlp.down_proj": {
    "combined_importance": 0.347,
    ...
  }
}
```

**Key field:** `combined_importance` - This is what GASQ uses!

- **High (0.8-1.0)**: Layer adapted heavily → 8-bit
- **Medium (0.6-0.8)**: Moderate adaptation → 6-bit  
- **Low (0.0-0.6)**: Minimal change → 4-bit

---

## Expected Output

After quantization completes, you'll have:

```
model-quantized/
├── quantized_model/          ← Your quantized model (3.5-4.2 GB)
│   ├── model.safetensors
│   ├── config.json
│   └── tokenizer files...
├── gasq_report.json         ← Detailed bit allocation report
├── awq_scores.json          ← AWQ scores per layer
└── gptq_scores.json         ← GPTQ scores per layer
```

### Sample gasq_report.json

```json
{
  "results": {
    "avg_bits": 4.8,
    "compression_ratio": 3.33,
    "bit_distribution": {
      "8-bit": 6,   // Attention Q/K/V, LM head
      "6-bit": 8,   // Attention O, MLP up
      "4-bit": 14   // MLP down, norms, embeddings
    }
  },
  "layer_details": [
    {
      "name": "model.layers.0.self_attn.q_proj",
      "type": "attention_q",
      "bits": 8,
      "scores": {
        "gradient": 0.892,  // From your gradient_stats.json
        "awq": 0.735,       // Computed during quantization
        "gptq": 0.828,      // Computed during quantization
        "combined": 0.827   // Final GASQ score
      }
    }
  ]
}
```

---

## Load and Test Your Quantized Model

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

# Load quantized model
model = AutoModelForCausalLM.from_pretrained(
    "./model-quantized/quantized_model",
    device_map="auto"
)

tokenizer = AutoTokenizer.from_pretrained(
    "./model-quantized/quantized_model"
)

# Test it
prompt = "Generate SQL for: Find all users who signed up in 2024"
inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
outputs = model.generate(**inputs, max_length=150)
print(tokenizer.decode(outputs[0]))
```

---

## Troubleshooting

### "gradient_stats.json not found"
Make sure the path is correct. Your gradient stats should be wherever you saved them during fine-tuning.

### "Out of memory during quantization"
```bash
# Reduce calibration samples
python quantize_model.py \
    --num_calibration_samples 128  # Instead of 512
```

### "Model size is 4.8 GB, not 3.5 GB"
This means average bits is higher than 4.0. To get exactly 3.5 GB:
```bash
python quantize_model.py \
    --target_bits 4.0  # Forces 4-bit average
```

If still higher, check `gasq_report.json` - you may have many 8-bit layers. This is intentional if your model needs them for accuracy!

---

## Expected Results

**For 7B Text-to-SQL Model:**

| Method | Size | SQL Accuracy | Time to Quantize |
|--------|------|--------------|------------------|
| Uniform 4-bit | 3.5 GB | 92% | ~1 hour |
| GASQ (4.0-bit avg) | 3.5 GB | 96% | ~2.5 hours |
| GASQ (4.8-bit avg) | 4.2 GB | 96.5% | ~2.5 hours |

**Your choice:**
- Want exactly 3.5 GB? → Set `--target_bits 4.0`
- Want best accuracy? → Set `--target_bits 4.8` (accept 4.2 GB)

---

## Files You Need from This Package

Minimum required files:
- `quantize_model.py` ✓
- `gasq_quantizer.py` ✓
- `awq_scorer.py` ✓
- `gptq_scorer.py` ✓
- `requirements.txt` ✓

Optional:
- `quantize_only.sh` (convenience script)
- `README.md` (full docs)

---

## Next Steps

1. Run quantization (2-3 hours)
2. Review `gasq_report.json`
3. Test quantized model on your task
4. Compare to baseline 4-bit model
5. If GASQ gives +3% accuracy, deploy it!

Questions? Check `README.md` for full documentation.

Happy quantizing! 🚀
