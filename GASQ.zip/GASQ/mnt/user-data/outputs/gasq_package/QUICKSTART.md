# GASQ Quick Reference Guide

## One-Command Execution

### Automated Full Pipeline
```bash
chmod +x run_all.sh
./run_all.sh
```

### Manual Step-by-Step
```bash
# Single GPU
python 1_train_with_gradient_tracking.py
python 2_compute_awq_scores.py
python 3_compute_gptq_sensitivity.py
python 4_gasq_fusion.py
python 5_quantize_model.py
python 6_evaluate.py

# Multi-GPU (4 GPUs)
torchrun --nproc_per_node=4 1_train_with_gradient_tracking.py
python 2_compute_awq_scores.py  # Steps 2-6 run on single GPU
python 3_compute_gptq_sensitivity.py
python 4_gasq_fusion.py
python 5_quantize_model.py
python 6_evaluate.py
```

## Key Files to Check

### Configuration
- **Edit before running:** `configs/gasq_config.yaml`
- Change: `model.name`, `dataset.name`, GASQ weights

### Outputs
- **Gradient stats:** `./output/gradient_stats/merged_stats.json`
- **AWQ scores:** `./output/awq_stats/awq_scores.json`
- **GPTQ sensitivity:** `./output/gptq_stats/gptq_sensitivity.json`
- **GASQ combined:** `./output/gasq_stats/gasq_combined.json`
- **Evaluation:** `./output/evaluation_results.json` ← **CHECK THIS**

### Models
- **Fine-tuned:** `./output/qwen_sql_qlora/`
- **Baseline 4-bit:** `./output/quantized_models/baseline_4bit/`
- **GASQ mixed:** `./output/quantized_models/gasq_mixed/`

## Common Customizations

### 1. Use Different Model
```yaml
# configs/gasq_config.yaml
model:
  name: "mistralai/Mistral-7B-Instruct-v0.3"  # Instead of Qwen
```

### 2. Use Different Dataset
```yaml
# configs/gasq_config.yaml
dataset:
  name: "your-org/your-dataset"
```

Then modify `format_for_sft()` in `1_train_with_gradient_tracking.py`

### 3. Adjust Compression Target
```yaml
# configs/gasq_config.yaml
gasq:
  bit_allocation:
    target_average_bits: 4.0  # More aggressive (smaller model)
    # or
    target_average_bits: 5.0  # More conservative (better quality)
```

### 4. Layer-Specific Weights
```yaml
# configs/gasq_config.yaml
gasq:
  weights:
    attention_q: [0.60, 0.20, 0.20]  # More emphasis on gradient
    mlp_down: [0.20, 0.50, 0.30]     # More emphasis on AWQ
```

## Interpreting Results

### evaluation_results.json
```json
{
  "baseline": {
    "exact_match": 92.0,      // % of perfect SQL matches
    "syntax_correctness": 95.0  // % of syntactically valid SQL
  },
  "gasq": {
    "exact_match": 96.0,      // +4% improvement!
    "syntax_correctness": 98.0
  },
  "avg_delta": 4.0,           // Average improvement
  "avg_bits_gasq": 4.5,       // GASQ average bit width
  "decision": "DEPLOY GASQ"   // ← Deployment recommendation
}
```

### Decision Logic
- **"DEPLOY GASQ"** → avg_delta > 3% AND bit_cost < 1.5
  - Use GASQ mixed-precision model
  
- **"USE BASELINE"** → avg_delta < 3%
  - Stick with uniform 4-bit
  
- **"MARGINAL"** → Good delta but high bit cost
  - Evaluate based on your deployment constraints

## Deployment

### Load Quantized Model
```python
from transformers import AutoModelForCausalLM, AutoTokenizer

# Load GASQ model
model = AutoModelForCausalLM.from_pretrained(
    "./output/quantized_models/gasq_mixed",
    device_map="auto"
)

tokenizer = AutoTokenizer.from_pretrained(
    "./output/quantized_models/gasq_mixed"
)

# Use for inference
prompt = "<|im_start|>user\nSELECT query<|im_end|>"
inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
outputs = model.generate(**inputs, max_new_tokens=256)
```

### Model Size Verification
```bash
# Check model sizes
du -h ./output/quantized_models/baseline_4bit
# Expected: ~3.5 GB

du -h ./output/quantized_models/gasq_mixed
# Expected: ~3.5-4.0 GB (depending on average bits)
```

## Troubleshooting

### Issue: OOM during training (Step 1)
```yaml
# Reduce batch size
training:
  per_device_train_batch_size: 2  # Instead of 4
  gradient_accumulation_steps: 8   # Instead of 4
```

### Issue: OOM during GPTQ (Step 3)
```yaml
# Use fewer calibration samples
gptq:
  calibration_samples: 64  # Instead of 128
```

### Issue: Layer names don't match
```bash
# Debug layer names
python -c "
import json
grad = json.load(open('./output/gradient_stats/merged_stats.json'))
awq = json.load(open('./output/awq_stats/awq_scores.json'))
print('Gradient layers:', list(grad.keys())[:5])
print('AWQ layers:', list(awq.keys())[:5])
"
```

### Issue: Distributed training stats not merging
```bash
# Check all ranks saved
ls -la ./output/gradient_stats/rank_*/

# Manual merge
python -c "
from utils.gradient_tracker import merge_distributed_stats
merge_distributed_stats('./output/gradient_stats', world_size=4)
"
```

## Performance Expectations

### Text-to-SQL (7B Model)
- **Baseline (4-bit):** 92% exact match, 3.5 GB
- **GASQ (4.5-bit):** 96% exact match, 3.9 GB
- **Improvement:** +4% for +400 MB

### Time per Step (A100 40GB)
1. Training (3 epochs): ~2-4 hours
2. AWQ: ~10-15 minutes
3. GPTQ: ~20-30 minutes
4. Fusion: ~1 minute
5. Quantization: ~5-10 minutes
6. Evaluation: ~15-20 minutes

**Total:** ~3-5 hours for complete pipeline

## Next Steps After GASQ

### Option 1: Deploy GASQ Model
```python
# Production inference
model = AutoModelForCausalLM.from_pretrained(
    "./output/quantized_models/gasq_mixed",
    device_map="auto"
)
```

### Option 2: Further Optimize
- Try different adaptive weights per layer
- Experiment with target_average_bits
- Run ablation studies

### Option 3: Compare Against QAT
```bash
# Quantization-Aware Training baseline
# Modify training script to include quantization in training loop
```

## Citation
```bibtex
@article{gasq2024,
  title={GASQ: Gradient-Activation Selective Quantization},
  author={Your Name},
  year={2024}
}
```
