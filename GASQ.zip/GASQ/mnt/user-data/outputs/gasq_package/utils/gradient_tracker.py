"""
Gradient Statistics Tracker
Based on user's gradient_tracker.py implementation
Tracks gradient statistics during QLoRA fine-tuning for GASQ
"""

import torch
import torch.nn as nn
import json
import time
import os
import threading
from typing import Dict, Any, Optional
from collections import defaultdict


class GradientStatTracker:
    """
    Track gradient statistics during training for GASQ quantization.
    
    Tracks per-layer:
    - ema_fast: Fast exponential moving average of gradient norms
    - ema_slow: Slow exponential moving average of gradient norms  
    - variance: Gradient variance
    - max_abs: Maximum absolute gradient seen
    - sign_consistency: Gradient sign consistency
    - update_count: Number of updates
    """
    
    def __init__(
        self,
        model: nn.Module,
        save_dir: str = "./gradient_stats",
        ema_fast_decay: float = 0.9,
        ema_slow_decay: float = 0.999,
        save_every_updates: int = 100,
        save_every_seconds: int = 300,
        verbose: bool = True
    ):
        self.model = model
        self.save_dir = save_dir
        self.ema_fast_decay = ema_fast_decay
        self.ema_slow_decay = ema_slow_decay
        self.save_every_updates = save_every_updates
        self.save_every_seconds = save_every_seconds
        self.verbose = verbose
        
        # Create save directory
        os.makedirs(save_dir, exist_ok=True)
        self.stats_path = os.path.join(save_dir, "stats.json")
        
        # Statistics storage
        self.stats = defaultdict(lambda: self._empty_param_stats())
        self.total_updates = 0
        self.last_save_time = time.time()
        
        # Thread safety
        self._lock = threading.Lock()
        
        # Register hooks
        self._register_hooks()
        
        if self.verbose:
            print(f"[GradientStatTracker] Initialized. Tracking {len(self.stats)} layers.")
    
    def _empty_param_stats(self) -> Dict[str, Any]:
        """Initialize empty statistics for a parameter."""
        return {
            'ema_fast': 0.0,
            'ema_slow': 0.0,
            'variance': 0.0,
            'max_abs': 0.0,
            'sign_consistency': 0.0,
            'sign_flips': 0,
            'update_to_weight_ratio': 0.0,
            'grad_sparsity': 0.0,
            'update_count': 0,
            'welford_n': 0,
            'welford_mean': 0.0,
            'welford_M2': 0.0,
        }
    
    def _register_hooks(self):
        """Register backward hooks on all Linear layers."""
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Linear):
                # Only track layers with gradients (not frozen)
                if module.weight.requires_grad:
                    module.register_full_backward_hook(
                        self._make_hook(name)
                    )
    
    def _make_hook(self, layer_name: str):
        """Create a backward hook for a specific layer."""
        def hook(module, grad_input, grad_output):
            if module.weight.grad is not None:
                self._update_stats(layer_name, module.weight.grad, module.weight.data)
        return hook
    
    def _update_stats(self, layer_name: str, grad: torch.Tensor, weight: torch.Tensor):
        """Update statistics for a layer's gradients."""
        with self._lock:
            stats = self.stats[layer_name]
            
            # Compute gradient norm
            grad_norm = torch.norm(grad).item()
            
            # Update EMAs
            alpha_fast = 1 - self.ema_fast_decay
            alpha_slow = 1 - self.ema_slow_decay
            
            stats['ema_fast'] = self.ema_fast_decay * stats['ema_fast'] + alpha_fast * grad_norm
            stats['ema_slow'] = self.ema_slow_decay * stats['ema_slow'] + alpha_slow * grad_norm
            
            # Update max absolute value
            max_abs = torch.max(torch.abs(grad)).item()
            stats['max_abs'] = max(stats['max_abs'], max_abs)
            
            # Update Welford variance (numerically stable)
            stats['update_count'] += 1
            n = stats['update_count']
            delta = grad_norm - stats['welford_mean']
            stats['welford_mean'] += delta / n
            delta2 = grad_norm - stats['welford_mean']
            stats['welford_M2'] += delta * delta2
            
            if n > 1:
                stats['variance'] = stats['welford_M2'] / (n - 1)
            
            # Gradient sparsity
            zero_ratio = (grad.abs() < 1e-8).float().mean().item()
            stats['grad_sparsity'] = 0.99 * stats['grad_sparsity'] + 0.01 * zero_ratio
            
            # Update-to-weight ratio
            if torch.norm(weight) > 1e-8:
                ratio = grad_norm / (torch.norm(weight).item() + 1e-8)
                stats['update_to_weight_ratio'] = 0.99 * stats['update_to_weight_ratio'] + 0.01 * ratio
            
            self.total_updates += 1
    
    def compute_combined_importance(self, base_layer: str) -> Dict[str, float]:
        """
        Compute combined importance score for a base layer.
        Averages across LoRA sides (lora_A, lora_B) if present.
        """
        param_stats = {}
        
        # Find all related parameters (lora_A, lora_B, or base)
        for layer_name in self.stats.keys():
            if base_layer in layer_name:
                param_stats[layer_name] = self.stats[layer_name]
        
        if not param_stats:
            return {'combined_importance': 0.0, 'update_count': 0}
        
        # Average statistics across sides
        ema_fast = sum(s['ema_fast'] for s in param_stats.values()) / len(param_stats)
        ema_slow = sum(s['ema_slow'] for s in param_stats.values()) / len(param_stats)
        variance = sum(s['variance'] for s in param_stats.values()) / len(param_stats)
        max_abs = max(s['max_abs'] for s in param_stats.values())
        
        # Compute combined importance
        variance_norm = variance / (ema_slow * ema_slow + 1e-8)
        importance = (ema_slow + 0.5 * ema_fast) * (1 + max_abs / (ema_slow + 1e-8)) * (1 + variance_norm)
        
        return {
            'combined_importance': importance,
            'ema_fast': ema_fast,
            'ema_slow': ema_slow,
            'variance': variance,
            'max_abs': max_abs,
            'update_count': sum(s['update_count'] for s in param_stats.values())
        }
    
    def save_stats(self):
        """Save current statistics to JSON."""
        export_data = {}
        
        # Group by base layer name
        base_layers = set()
        for layer_name in self.stats.keys():
            # Extract base name (remove lora_A/lora_B suffix)
            if 'lora_A' in layer_name:
                base = layer_name.replace('.lora_A', '')
            elif 'lora_B' in layer_name:
                base = layer_name.replace('.lora_B', '')
            else:
                base = layer_name
            base_layers.add(base)
        
        # Compute combined importance for each base layer
        for base in base_layers:
            export_data[base] = self.compute_combined_importance(base)
        
        # Add metadata
        export_data['_metadata'] = {
            'total_updates': self.total_updates,
            'ema_fast_decay': self.ema_fast_decay,
            'ema_slow_decay': self.ema_slow_decay,
            'timestamp': time.time()
        }
        
        # Write to file
        with self._lock:
            with open(self.stats_path, 'w') as f:
                json.dump(export_data, f, indent=2)
        
        if self.verbose:
            print(f"[GradientStatTracker] Saved stats to {self.stats_path}")
    
    def maybe_save_async(self):
        """Check if should save and save asynchronously if needed."""
        now = time.time()
        should_save = (
            (self.total_updates > 0 and self.total_updates % self.save_every_updates == 0) or
            (now - self.last_save_time >= self.save_every_seconds)
        )
        
        if should_save:
            self.last_save_time = now
            # Save in background thread to not block training
            threading.Thread(target=self.save_stats, daemon=True).start()
    
    def force_save(self):
        """Force immediate save (blocking)."""
        self.save_stats()
    
    def summary(self) -> Dict[str, Any]:
        """Return summary statistics."""
        importances = []
        for base in set(k.split('.lora_')[0] if '.lora_' in k else k for k in self.stats.keys()):
            imp = self.compute_combined_importance(base)
            importances.append(imp['combined_importance'])
        
        return {
            'total_layers': len(importances),
            'total_updates': self.total_updates,
            'mean_importance': sum(importances) / len(importances) if importances else 0,
            'max_importance': max(importances) if importances else 0,
            'min_importance': min(importances) if importances else 0
        }


def merge_distributed_stats(save_dir: str, world_size: int, output_name: str = "merged_stats.json") -> str:
    """
    Merge gradient statistics from distributed training across multiple ranks.
    
    Args:
        save_dir: Directory containing rank_*.json files
        world_size: Number of distributed ranks
        output_name: Name of merged output file
        
    Returns:
        Path to merged stats file
    """
    rank_files = [os.path.join(save_dir, f"rank_{r}", "stats.json") for r in range(world_size)]
    
    # Check all files exist
    for path in rank_files:
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Missing stats file: {path}")
    
    # Load all rank files
    rank_data = []
    for path in rank_files:
        with open(path, 'r') as f:
            rank_data.append(json.load(f))
    
    # Merge using Welford's algorithm for variance
    merged = {}
    
    # Get all layer names
    all_layers = set()
    for data in rank_data:
        all_layers.update(k for k in data.keys() if k != '_metadata')
    
    for layer in all_layers:
        # Initialize merged entry
        merged[layer] = {
            'combined_importance': 0.0,
            'ema_fast': 0.0,
            'ema_slow': 0.0,
            'variance': 0.0,
            'max_abs': 0.0,
            'update_count': 0,
        }
        
        # Collect data from all ranks
        layer_data = []
        for data in rank_data:
            if layer in data:
                layer_data.append(data[layer])
        
        if not layer_data:
            continue
        
        # Merge statistics
        total_updates = sum(d['update_count'] for d in layer_data)
        if total_updates == 0:
            continue
        
        # Weighted average by update count
        weights = [d['update_count'] / total_updates for d in layer_data]
        
        merged[layer]['ema_fast'] = sum(w * d['ema_fast'] for w, d in zip(weights, layer_data))
        merged[layer]['ema_slow'] = sum(w * d['ema_slow'] for w, d in zip(weights, layer_data))
        merged[layer]['variance'] = sum(w * d['variance'] for w, d in zip(weights, layer_data))
        merged[layer]['max_abs'] = max(d['max_abs'] for d in layer_data)
        merged[layer]['update_count'] = total_updates
        
        # Recompute combined importance
        ema_slow = merged[layer]['ema_slow']
        ema_fast = merged[layer]['ema_fast']
        variance = merged[layer]['variance']
        max_abs = merged[layer]['max_abs']
        
        variance_norm = variance / (ema_slow * ema_slow + 1e-8)
        merged[layer]['combined_importance'] = (
            (ema_slow + 0.5 * ema_fast) * 
            (1 + max_abs / (ema_slow + 1e-8)) * 
            (1 + variance_norm)
        )
    
    # Add metadata
    merged['_metadata'] = {
        'world_size': world_size,
        'total_updates': sum(d.get('_metadata', {}).get('total_updates', 0) for d in rank_data),
        'merged_timestamp': time.time()
    }
    
    # Save merged file
    merged_path = os.path.join(save_dir, output_name)
    with open(merged_path, 'w') as f:
        json.dump(merged, f, indent=2)
    
    print(f"[MergeStats] Merged {world_size} ranks into {merged_path}")
    return merged_path
