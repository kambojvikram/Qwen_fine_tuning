# GASQ: Gradient-Activation Selective Quantization
**Complete Pipeline for Task-Aware 7B Model Quantization**

## Overview
GASQ combines gradient statistics from fine-tuning with AWQ and GPTQ to create task-aware mixed-precision quantized models. Instead of uniform quantization, GASQ intelligently allocates bits: 8-bit for task-critical layers, 4-bit for general-purpose layers, achieving better task retention at the same compression ratio.

**Key Innovation:** Uses fine-tuning gradients to identify which layers adapted for your specific task (e.g., text-to-SQL), then preserves precision where it matters most.

## Directory Structure
```
gasq/
├── 1_train_with_gradient_tracking.py  # Fine-tuning + gradient collection
├── 2_compute_awq_scores.py            # Activation importance analysis
├── 3_compute_gptq_sensitivity.py      # Mathematical quantization sensitivity
├── 4_gasq_fusion.py                   # Adaptive signal fusion
├── 5_quantize_model.py                # Apply quantization
├── 6_evaluate.py                      # Conservative validation
├── utils/
│   └── gradient_tracker.py            # Gradient statistics tracker
├── configs/
│   └── gasq_config.yaml               # All hyperparameters
├── requirements.txt
└── README.md
```

## Installation

```bash
# Create environment
conda create -n gasq python=3.10
conda activate gasq

# Install dependencies
pip install -r requirements.txt

# For multi-GPU training
pip install deepspeed
```

## Quick Start

### 1. Configure Your Model
Edit `configs/gasq_config.yaml`:
```yaml
model:
  name: "Qwen/Qwen2.5-7B-Instruct"  # Your 7B model

dataset:
  name: "gretelai/synthetic_text_to_sql"  # Your dataset
```

### 2. Run Complete Pipeline

**Single GPU:**
```bash
python 1_train_with_gradient_tracking.py
python 2_compute_awq_scores.py
python 3_compute_gptq_sensitivity.py
python 4_gasq_fusion.py
python 5_quantize_model.py
python 6_evaluate.py
```

**Multi-GPU (4 GPUs):**
```bash
torchrun --nproc_per_node=4 1_train_with_gradient_tracking.py
python 2_compute_awq_scores.py
python 3_compute_gptq_sensitivity.py
python 4_gasq_fusion.py
python 5_quantize_model.py
python 6_evaluate.py
```

## Pipeline Steps Explained

### Step 1: Train with Gradient Tracking
```bash
python 1_train_with_gradient_tracking.py
```
- Fine-tunes model with QLoRA on your dataset
- Tracks gradient statistics (EMA, variance, max absolute values)
- Saves gradient stats to `./output/gradient_stats/merged_stats.json`
- **Output:** Fine-tuned model + gradient statistics

**What it tracks:**
- Which layers changed during fine-tuning (task adaptation)
- Gradient magnitude, variance, and stability
- Layer-wise importance for your specific task

### Step 2: Compute AWQ Scores
```bash
python 2_compute_awq_scores.py
```
- Measures activation magnitudes during inference
- Identifies layers with high runtime impact
- Uses test set for calibration (different from training)
- **Output:** AWQ scores in `./output/awq_stats/awq_scores.json`

**What it measures:**
- Which weights produce large activations
- Runtime importance of each layer
- Inference-critical components

### Step 3: Compute GPTQ Sensitivity
```bash
python 3_compute_gptq_sensitivity.py
```
- Approximates Hessian (second-order curvature)
- Identifies mathematically sensitive layers
- Uses FP32 for accurate computation
- **Output:** Sensitivity scores in `./output/gptq_stats/gptq_sensitivity.json`

**What it measures:**
- Quantization error propagation
- Mathematical fragility to precision loss
- Layers requiring higher precision

### Step 4: GASQ Fusion
```bash
python 4_gasq_fusion.py
```
- Combines all three signals with adaptive weights
- Different weights per layer type (attention vs MLP)
- Allocates bits to meet target average (4.0-5.0 bits)
- **Output:** Combined scores in `./output/gasq_stats/gasq_combined.json`

**Adaptive weighting example:**
- Attention Q/K/V: `[0.50, 0.25, 0.25]` (emphasize gradient)
- MLP down: `[0.25, 0.40, 0.35]` (emphasize AWQ)
- Layer norms: `[0.20, 0.40, 0.40]` (de-emphasize gradient)

### Step 5: Quantize Model
```bash
python 5_quantize_model.py
```
- Creates baseline: uniform 4-bit
- Creates GASQ: mixed-precision (4/6/8-bit)
- Saves both models for comparison
- **Output:** Quantized models in `./output/quantized_models/`

**Compression:**
- 7B params × 4 bits = 28 Gb = **3.5 GB** (baseline)
- 7B params × 4.5 bits avg = 31.5 Gb = **3.9 GB** (GASQ)

### Step 6: Evaluate
```bash
python 6_evaluate.py
```
- Tests both baseline and GASQ on held-out data
- Computes accuracy metrics (exact match, syntax correctness)
- **Conservative decision criteria:**
  - ✓ Deploy GASQ if: accuracy gain > 3% AND bit cost < 1.5
  - ✗ Use baseline if: accuracy gain < 3%

**Example results:**
```
Baseline (4-bit):    92.0% accuracy
GASQ (4.5-bit):      96.0% accuracy
Delta:               +4.0% ← Justifies complexity!
```

## Configuration Guide

### Key Parameters in `gasq_config.yaml`

**Model & Training:**
```yaml
model:
  name: "Qwen/Qwen2.5-7B-Instruct"
  
training:
  num_train_epochs: 3
  per_device_train_batch_size: 4
  learning_rate: 2.0e-4
```

**GASQ Fusion:**
```yaml
gasq:
  weights:
    attention_q: [0.50, 0.25, 0.25]  # [gradient, awq, gptq]
    mlp_down: [0.25, 0.40, 0.35]
    
  bit_allocation:
    high_precision_threshold: 0.75  # 8-bit
    medium_precision_threshold: 0.60  # 6-bit
    target_average_bits: 4.5
```

**Learn optimal weights:**
```yaml
# Option 1: Grid search on validation set
# Option 2: Use heuristic rules (current approach)
```

## Expected Results

### For Text-to-SQL Task

**Baseline (Uniform 4-bit):**
- Model size: 3.5 GB
- SQL accuracy: ~92%
- Compression: 4.0x from FP16

**GASQ (Mixed 4.5-bit avg):**
- Model size: 3.9 GB
- SQL accuracy: ~96%
- Compression: 3.6x from FP16
- **Gain: +4% accuracy for +0.4 GB**

**Bit allocation pattern:**
- 8-bit: Attention Q/K/V (learned SQL patterns)
- 6-bit: Output projections, MLP up
- 4-bit: MLP down, layer norms, embeddings

## Hardware Requirements

**Minimum:**
- GPU: 1x RTX 4090 (24GB) or A100 (40GB)
- RAM: 64 GB
- Storage: 50 GB

**Recommended (Multi-GPU):**
- GPU: 4x A100 (40GB)
- RAM: 128 GB
- Storage: 100 GB

**Memory usage per step:**
- Step 1 (Training): ~20 GB per GPU
- Step 2 (AWQ): ~16 GB
- Step 3 (GPTQ): ~28 GB (FP32)
- Steps 4-6: ~16 GB

## Troubleshooting

**OOM during Step 3 (GPTQ):**
```bash
# Reduce calibration samples
gptq:
  calibration_samples: 64  # Instead of 128
```

**Gradient stats not merging:**
```bash
# Check all ranks saved stats
ls ./output/gradient_stats/rank_*/stats.json

# Manually merge
python -c "from utils.gradient_tracker import merge_distributed_stats; \
           merge_distributed_stats('./output/gradient_stats', world_size=4)"
```

**Layer name mismatches:**
```bash
# Print layer names from each source
python -c "import json; \
           grad = json.load(open('./output/gradient_stats/merged_stats.json')); \
           print(list(grad.keys())[:10])"
```

## Advanced Usage

### Custom Dataset
```python
# Modify format_for_sft() in 1_train_with_gradient_tracking.py
def format_for_sft(row):
    return {
        "system": row['your_system_field'],
        "user": row['your_user_field'],
        "assistant": row['your_assistant_field']
    }
```

### Different Model Architecture
```yaml
# For models with different layer naming:
lora:
  target_modules: ["q_proj", "k_proj", ...]  # Adjust as needed
```

### Adjust Bit Allocation
```yaml
gasq:
  bit_allocation:
    high_precision_threshold: 0.80  # More conservative (fewer 8-bit)
    medium_precision_threshold: 0.65
    target_average_bits: 4.0  # More aggressive compression
```

## Citation

If you use GASQ in your research:
```bibtex
@article{gasq2024,
  title={GASQ: Gradient-Activation Selective Quantization for Task-Aware Model Compression},
  author={Your Name},
  year={2024}
}
```

## License
MIT License - See LICENSE file

## Support
For issues, questions, or contributions, please open a GitHub issue.