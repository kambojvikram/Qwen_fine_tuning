"""
GPTQ Sensitivity Scorer
Computes quantization sensitivity using Hessian approximation
"""

import torch
import torch.nn as nn
from typing import Dict, List
from tqdm import tqdm
import logging

logger = logging.getLogger(__name__)


class GPTQSensitivityScorer:
    """
    Computes GPTQ sensitivity scores using Hessian diagonal approximation.
    Measures how sensitive each layer is to quantization errors.
    """
    
    def __init__(self, model: nn.Module, device: str = "cuda"):
        self.model = model
        self.device = device
        self.hessian_stats = {}
        self.hooks = []
    
    def _get_hessian_hook(self, name: str):
        """Create hook to accumulate Hessian information"""
        def hook(module, grad_input, grad_output):
            # Only process Linear layers with weights
            if not hasattr(module, 'weight') or module.weight is None:
                return
            
            # Get gradient w.r.t output
            if isinstance(grad_output, tuple):
                grad_out = grad_output[0]
            else:
                grad_out = grad_output
            
            if grad_out is None:
                return
            
            # Approximate Hessian diagonal as gradient squared
            # This is the Fisher Information approximation
            grad_squared = grad_out.pow(2)
            
            # Average over batch and sequence
            if grad_squared.dim() >= 2:
                hess_diag = grad_squared.mean(dim=list(range(grad_squared.dim() - 1)))
            else:
                hess_diag = grad_squared
            
            # Accumulate
            if name not in self.hessian_stats:
                self.hessian_stats[name] = {
                    'hessian_sum': torch.zeros_like(hess_diag),
                    'count': 0
                }
            
            self.hessian_stats[name]['hessian_sum'] += hess_diag.detach().cpu()
            self.hessian_stats[name]['count'] += 1
        
        return hook
    
    def register_hooks(self):
        """Register backward hooks on all Linear layers"""
        for name, module in self.model.named_modules():
            if isinstance(module, (nn.Linear, nn.Conv1d, nn.Conv2d)):
                hook = module.register_full_backward_hook(self._get_hessian_hook(name))
                self.hooks.append(hook)
        
        logger.info(f"Registered GPTQ hooks on {len(self.hooks)} layers")
    
    def remove_hooks(self):
        """Remove all hooks"""
        for hook in self.hooks:
            hook.remove()
        self.hooks = []
    
    def compute_scores(
        self,
        calibration_dataloader,
        num_batches: int = 128
    ) -> Dict[str, float]:
        """
        Compute GPTQ sensitivity scores using calibration data.
        
        Args:
            calibration_dataloader: DataLoader with calibration samples
            num_batches: Number of batches to use
        
        Returns:
            Dictionary mapping layer names to GPTQ sensitivity scores
        """
        self.model.train()  # Need gradients
        self.hessian_stats = {}
        self.register_hooks()
        
        logger.info("Computing GPTQ sensitivity scores...")
        
        try:
            for i, batch in enumerate(tqdm(calibration_dataloader,
                                          desc="GPTQ Calibration",
                                          total=num_batches)):
                if i >= num_batches:
                    break
                
                self.model.zero_grad()
                
                # Move batch to device and compute loss
                if isinstance(batch, dict):
                    batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                            for k, v in batch.items()}
                    outputs = self.model(**batch)
                else:
                    if isinstance(batch, (tuple, list)):
                        batch = tuple(x.to(self.device) if isinstance(x, torch.Tensor) else x 
                                     for x in batch)
                        outputs = self.model(*batch)
                    else:
                        batch = batch.to(self.device)
                        outputs = self.model(batch)
                
                # Get loss
                if hasattr(outputs, 'loss') and outputs.loss is not None:
                    loss = outputs.loss
                elif isinstance(outputs, dict) and 'loss' in outputs:
                    loss = outputs['loss']
                elif isinstance(outputs, tuple):
                    loss = outputs[0] if len(outputs) > 0 else None
                else:
                    # If no loss, use mean of outputs as proxy
                    if isinstance(outputs, torch.Tensor):
                        loss = outputs.mean()
                    else:
                        logger.warning("Could not compute loss from outputs")
                        continue
                
                # Backward pass to compute gradients
                if loss is not None:
                    loss.backward()
        
        finally:
            self.remove_hooks()
            self.model.eval()
        
        # Compute final GPTQ sensitivity scores
        gptq_scores = {}
        for name, stats in self.hessian_stats.items():
            if stats['count'] > 0:
                # Average Hessian diagonal across calibration samples
                avg_hessian = stats['hessian_sum'] / stats['count']
                # Use mean of Hessian diagonal as sensitivity score
                # Higher Hessian = more sensitive to quantization
                gptq_scores[name] = float(avg_hessian.mean().item())
        
        logger.info(f"Computed GPTQ scores for {len(gptq_scores)} layers")
        
        # Normalize scores
        if gptq_scores:
            max_score = max(gptq_scores.values())
            if max_score > 0:
                gptq_scores = {k: v / max_score for k, v in gptq_scores.items()}
        
        return gptq_scores


def compute_gptq_scores_simple(
    model: nn.Module,
    calibration_dataloader,
    device: str = "cuda",
    num_batches: int = 128
) -> Dict[str, float]:
    """
    Convenience function to compute GPTQ sensitivity scores.
    
    Args:
        model: The model to analyze
        calibration_dataloader: DataLoader with calibration data
        device: Device to run on
        num_batches: Number of calibration batches
    
    Returns:
        Dictionary mapping layer names to GPTQ sensitivity scores
    """
    scorer = GPTQSensitivityScorer(model, device=device)
    return scorer.compute_scores(calibration_dataloader, num_batches=num_batches)
