"""
GASQ (Gradient-Activation Selective Quantization)
Main quantization orchestrator that combines gradient stats, AWQ, and GPTQ
"""

import json
import torch
import numpy as np
from typing import Dict, List, Tuple, Any
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GASQQuantizer:
    """
    Combines gradient statistics, AWQ scores, and GPTQ sensitivity
    to produce optimal mixed-precision quantization for task-specific models.
    """
    
    def __init__(
        self,
        gradient_stats_path: str,
        target_avg_bits: float = 4.0,
        adaptive_weights: bool = True,
        conservative: bool = True
    ):
        """
        Args:
            gradient_stats_path: Path to gradient statistics from fine-tuning
            target_avg_bits: Target average bit width (4.0-5.0 recommended)
            adaptive_weights: Use layer-type specific weights vs fixed 40/30/30
            conservative: Use conservative bit allocation (4/6/8 only, no 2/3)
        """
        self.gradient_stats_path = gradient_stats_path
        self.target_avg_bits = target_avg_bits
        self.adaptive_weights = adaptive_weights
        self.conservative = conservative
        
        # Load gradient statistics
        self.gradient_stats = self._load_gradient_stats()
        
        # Storage for other components
        self.awq_scores = {}
        self.gptq_scores = {}
        self.combined_scores = {}
        self.bit_allocations = {}
        
        logger.info(f"GASQ Quantizer initialized")
        logger.info(f"Target average: {target_avg_bits} bits")
        logger.info(f"Adaptive weights: {adaptive_weights}")
        logger.info(f"Conservative mode: {conservative}")
    
    def _load_gradient_stats(self) -> Dict[str, Any]:
        """Load gradient statistics from fine-tuning"""
        with open(self.gradient_stats_path, 'r') as f:
            stats = json.load(f)
        logger.info(f"Loaded gradient stats for {len(stats)} layers")
        return stats
    
    def get_layer_type(self, layer_name: str) -> str:
        """Determine layer type from name"""
        layer_lower = layer_name.lower()
        
        if 'embed' in layer_lower:
            return 'embedding'
        elif 'lm_head' in layer_lower or 'lm.head' in layer_lower:
            return 'lm_head'
        elif 'layernorm' in layer_lower or 'layer_norm' in layer_lower or 'ln' in layer_lower:
            return 'layer_norm'
        elif 'q_proj' in layer_lower or 'query' in layer_lower:
            return 'attention_q'
        elif 'k_proj' in layer_lower or 'key' in layer_lower:
            return 'attention_k'
        elif 'v_proj' in layer_lower or 'value' in layer_lower:
            return 'attention_v'
        elif 'o_proj' in layer_lower or 'out_proj' in layer_lower or 'dense' in layer_lower:
            return 'attention_o'
        elif 'gate_proj' in layer_lower or 'up_proj' in layer_lower or 'fc1' in layer_lower:
            return 'mlp_up'
        elif 'down_proj' in layer_lower or 'fc2' in layer_lower:
            return 'mlp_down'
        else:
            return 'other'
    
    def get_adaptive_weights(self, layer_type: str) -> Tuple[float, float, float]:
        """
        Get adaptive weights for gradient/AWQ/GPTQ based on layer type.
        Returns (w_grad, w_awq, w_gptq) that sum to 1.0
        """
        if not self.adaptive_weights:
            # Fixed weights (baseline)
            return (0.40, 0.30, 0.30)
        
        # Layer-specific adaptive weights
        weights = {
            'attention_q': (0.50, 0.25, 0.25),  # Gradient most important
            'attention_k': (0.50, 0.25, 0.25),
            'attention_v': (0.50, 0.25, 0.25),
            'attention_o': (0.40, 0.25, 0.35),  # Balance grad + GPTQ
            'mlp_up': (0.35, 0.30, 0.35),       # Moderate gradient
            'mlp_down': (0.25, 0.40, 0.35),     # AWQ more predictive
            'layer_norm': (0.20, 0.40, 0.40),   # Gradient least important
            'embedding': (0.30, 0.35, 0.35),    # Moderate all
            'lm_head': (0.35, 0.30, 0.35),      # All signals critical
            'other': (0.33, 0.33, 0.34),        # Equal weight
        }
        
        return weights.get(layer_type, (0.33, 0.33, 0.34))
    
    def normalize_scores(self, scores: Dict[str, float]) -> Dict[str, float]:
        """Normalize scores to [0, 1] range"""
        values = list(scores.values())
        if not values:
            return scores
        
        min_val = min(values)
        max_val = max(values)
        
        if max_val - min_val < 1e-8:
            return {k: 0.5 for k in scores.keys()}
        
        return {
            k: (v - min_val) / (max_val - min_val)
            for k, v in scores.items()
        }
    
    def compute_combined_scores(self) -> Dict[str, float]:
        """
        Combine gradient, AWQ, GPTQ scores with adaptive weighting.
        Returns combined GASQ score for each layer.
        """
        # Normalize each component to [0, 1]
        grad_norm = self.normalize_scores(
            {k: v.get('combined_importance', 0.0) 
             for k, v in self.gradient_stats.items()}
        )
        awq_norm = self.normalize_scores(self.awq_scores)
        gptq_norm = self.normalize_scores(self.gptq_scores)
        
        # Compute combined scores with adaptive weights
        combined = {}
        for layer_name in self.gradient_stats.keys():
            layer_type = self.get_layer_type(layer_name)
            w_grad, w_awq, w_gptq = self.get_adaptive_weights(layer_type)
            
            grad_score = grad_norm.get(layer_name, 0.0)
            awq_score = awq_norm.get(layer_name, 0.0)
            gptq_score = gptq_norm.get(layer_name, 0.0)
            
            combined[layer_name] = (
                w_grad * grad_score +
                w_awq * awq_score +
                w_gptq * gptq_score
            )
        
        self.combined_scores = combined
        logger.info(f"Computed combined GASQ scores for {len(combined)} layers")
        return combined
    
    def allocate_bits(self) -> Dict[str, int]:
        """
        Allocate bits based on combined GASQ scores.
        Conservative mode: 4-bit base, 6-bit important, 8-bit critical
        """
        if not self.combined_scores:
            raise ValueError("Must compute combined scores first")
        
        # Sort layers by score
        sorted_layers = sorted(
            self.combined_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Iteratively adjust thresholds to hit target average
        best_allocation = None
        best_diff = float('inf')
        
        for high_thresh in np.arange(0.70, 0.85, 0.02):
            for mid_thresh in np.arange(0.55, 0.70, 0.02):
                allocation = {}
                for layer_name, score in sorted_layers:
                    if score > high_thresh:
                        bits = 8
                    elif score > mid_thresh:
                        bits = 6
                    else:
                        bits = 4
                    allocation[layer_name] = bits
                
                avg_bits = np.mean(list(allocation.values()))
                diff = abs(avg_bits - self.target_avg_bits)
                
                if diff < best_diff:
                    best_diff = diff
                    best_allocation = allocation
        
        self.bit_allocations = best_allocation
        avg_bits = np.mean(list(best_allocation.values()))
        
        # Count distribution
        count_8bit = sum(1 for b in best_allocation.values() if b == 8)
        count_6bit = sum(1 for b in best_allocation.values() if b == 6)
        count_4bit = sum(1 for b in best_allocation.values() if b == 4)
        
        logger.info(f"Bit allocation complete:")
        logger.info(f"  Average: {avg_bits:.2f} bits (target: {self.target_avg_bits})")
        logger.info(f"  8-bit: {count_8bit} layers ({count_8bit/len(best_allocation)*100:.1f}%)")
        logger.info(f"  6-bit: {count_6bit} layers ({count_6bit/len(best_allocation)*100:.1f}%)")
        logger.info(f"  4-bit: {count_4bit} layers ({count_4bit/len(best_allocation)*100:.1f}%)")
        
        return best_allocation
    
    def get_quantization_config(self) -> Dict[str, Any]:
        """
        Generate quantization config compatible with AutoGPTQ.
        Returns layer-specific bit allocation.
        """
        if not self.bit_allocations:
            raise ValueError("Must allocate bits first")
        
        return {
            'bits': self.bit_allocations,
            'group_size': 128,
            'desc_act': True,
            'sym': True,
            'true_sequential': True,
        }
    
    def save_report(self, output_path: str):
        """Save detailed GASQ quantization report"""
        report = {
            'config': {
                'target_avg_bits': self.target_avg_bits,
                'adaptive_weights': self.adaptive_weights,
                'conservative': self.conservative,
            },
            'results': {
                'avg_bits': float(np.mean(list(self.bit_allocations.values()))),
                'compression_ratio': 16.0 / np.mean(list(self.bit_allocations.values())),
                'num_layers': len(self.bit_allocations),
                'bit_distribution': {
                    '8-bit': sum(1 for b in self.bit_allocations.values() if b == 8),
                    '6-bit': sum(1 for b in self.bit_allocations.values() if b == 6),
                    '4-bit': sum(1 for b in self.bit_allocations.values() if b == 4),
                }
            },
            'layer_details': []
        }
        
        # Add per-layer details
        for layer_name in sorted(self.combined_scores.keys(), 
                                 key=lambda x: self.combined_scores[x], 
                                 reverse=True):
            layer_type = self.get_layer_type(layer_name)
            w_grad, w_awq, w_gptq = self.get_adaptive_weights(layer_type)
            
            report['layer_details'].append({
                'name': layer_name,
                'type': layer_type,
                'bits': self.bit_allocations[layer_name],
                'scores': {
                    'gradient': float(self.gradient_stats[layer_name].get('combined_importance', 0)),
                    'awq': float(self.awq_scores.get(layer_name, 0)),
                    'gptq': float(self.gptq_scores.get(layer_name, 0)),
                    'combined': float(self.combined_scores[layer_name]),
                },
                'weights': {
                    'gradient': w_grad,
                    'awq': w_awq,
                    'gptq': w_gptq,
                }
            })
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Saved GASQ report to {output_path}")
        return report
