"""
Step 2: Compute AWQ (Activation-Aware Weight Quantization) Scores
Measures which weights have high activation magnitudes during inference
"""

import os
import yaml
import torch
import json
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import pandas as pd
from datasets import Dataset


def load_config(config_path="configs/gasq_config.yaml"):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


class AWQScoreComputer:
    """
    Compute AWQ scores by measuring activation magnitudes.
    Higher scores indicate layers with greater runtime impact.
    """
    
    def __init__(self, model, tokenizer, config):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.activation_stats = {}
        self.hooks = []
        
    def _register_hooks(self):
        """Register forward hooks on all Linear layers."""
        def make_hook(name):
            def hook(module, input, output):
                # Measure activation magnitude
                with torch.no_grad():
                    activation = output.detach()
                    
                    # Compute L2 norm per output channel
                    # Shape: [batch, seq_len, hidden] -> [hidden]
                    if activation.dim() == 3:
                        activation = activation.reshape(-1, activation.size(-1))
                    
                    channel_norms = torch.norm(activation, p=2, dim=0)
                    
                    # Accumulate statistics
                    if name not in self.activation_stats:
                        self.activation_stats[name] = {
                            'sum_norms': torch.zeros_like(channel_norms),
                            'sum_squared_norms': torch.zeros_like(channel_norms),
                            'max_norms': torch.zeros_like(channel_norms),
                            'count': 0
                        }
                    
                    stats = self.activation_stats[name]
                    stats['sum_norms'] += channel_norms
                    stats['sum_squared_norms'] += channel_norms ** 2
                    stats['max_norms'] = torch.maximum(stats['max_norms'], channel_norms)
                    stats['count'] += 1
            
            return hook
        
        # Register hooks
        for name, module in self.model.named_modules():
            if isinstance(module, torch.nn.Linear):
                handle = module.register_forward_hook(make_hook(name))
                self.hooks.append(handle)
        
        print(f"[AWQ] Registered hooks on {len(self.hooks)} Linear layers")
    
    def _remove_hooks(self):
        """Remove all registered hooks."""
        for handle in self.hooks:
            handle.remove()
        self.hooks = []
    
    def compute_scores(self, calibration_dataset):
        """
        Run model on calibration data and compute AWQ scores.
        
        Args:
            calibration_dataset: Dataset to use for calibration
            
        Returns:
            Dict mapping layer names to AWQ scores
        """
        print(f"[AWQ] Computing scores on {len(calibration_dataset)} calibration samples")
        
        # Register hooks
        self._register_hooks()
        
        # Run inference on calibration data
        self.model.eval()
        
        with torch.no_grad():
            for i, sample in enumerate(tqdm(calibration_dataset, desc="AWQ Calibration")):
                # Tokenize
                inputs = self.tokenizer(
                    sample['text'],
                    return_tensors='pt',
                    truncation=True,
                    max_length=self.config['training']['max_seq_length']
                ).to(self.model.device)
                
                # Forward pass (hooks collect activations)
                _ = self.model(**inputs)
                
                # Limit calibration samples
                if i >= self.config['awq']['calibration_samples'] - 1:
                    break
        
        # Compute final scores
        awq_scores = {}
        
        for name, stats in self.activation_stats.items():
            if stats['count'] == 0:
                continue
            
            # Mean activation magnitude
            mean_norm = (stats['sum_norms'] / stats['count']).mean().item()
            
            # Variance of activation magnitude
            mean_squared = (stats['sum_squared_norms'] / stats['count']).mean().item()
            variance = mean_squared - mean_norm ** 2
            std = torch.sqrt(torch.tensor(max(0, variance))).item()
            
            # Max activation magnitude
            max_norm = stats['max_norms'].mean().item()
            
            # AWQ score combines mean, std, and max
            # Layers with high, variable activations get higher scores
            awq_score = mean_norm * (1 + std / (mean_norm + 1e-8)) * (1 + max_norm / (mean_norm + 1e-8))
            
            awq_scores[name] = {
                'awq_score': awq_score,
                'mean_activation': mean_norm,
                'std_activation': std,
                'max_activation': max_norm,
                'calibration_samples': stats['count']
            }
        
        # Remove hooks
        self._remove_hooks()
        
        print(f"[AWQ] Computed scores for {len(awq_scores)} layers")
        return awq_scores


def normalize_scores(scores_dict):
    """Normalize AWQ scores to [0, 1] range."""
    all_scores = [v['awq_score'] for v in scores_dict.values()]
    min_score = min(all_scores)
    max_score = max(all_scores)
    
    normalized = {}
    for name, data in scores_dict.items():
        normalized[name] = {
            **data,
            'awq_score_normalized': (data['awq_score'] - min_score) / (max_score - min_score + 1e-8)
        }
    
    return normalized


def main():
    config = load_config()
    
    print("[AWQ] Step 2: Computing AWQ Scores")
    print(f"Model: {config['model']['name']}")
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        config['model']['name'],
        trust_remote_code=True
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # Load fine-tuned model
    print("[Loading fine-tuned model...]")
    base_model = AutoModelForCausalLM.from_pretrained(
        config['model']['name'],
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    )
    
    # Load LoRA weights
    model = PeftModel.from_pretrained(
        base_model,
        config['training']['output_dir'],
        torch_dtype=torch.bfloat16
    )
    
    # Merge LoRA weights for accurate AWQ computation
    model = model.merge_and_unload()
    model.eval()
    
    print(f"[Model loaded with merged LoRA weights]")
    
    # Load calibration dataset
    print("[Loading calibration dataset...]")
    df = pd.read_parquet(
        f"hf://datasets/{config['dataset']['name']}/{config['dataset']['test_split']}.snappy.parquet"
    )
    
    # Use test set for calibration (different from training)
    calibration_dataset = Dataset.from_pandas(df)
    
    # Format dataset
    from train_with_gradient_tracking import format_for_sft
    calibration_dataset = calibration_dataset.map(format_for_sft)
    
    def create_conversation(row):
        return {
            "text": (
                f"<|im_start|>system\n{row['system']}<|im_end|>\n"
                f"<|im_start|>user\n{row['user']}<|im_end|>\n"
                f"<|im_start|>assistant\n{row['assistant']}<|im_end|>"
            )
        }
    
    calibration_dataset = calibration_dataset.map(create_conversation)
    
    # Limit to calibration samples
    n_samples = min(len(calibration_dataset), config['awq']['calibration_samples'])
    calibration_dataset = calibration_dataset.select(range(n_samples))
    
    print(f"[Using {len(calibration_dataset)} calibration samples]")
    
    # Compute AWQ scores
    awq_computer = AWQScoreComputer(model, tokenizer, config)
    awq_scores = awq_computer.compute_scores(calibration_dataset)
    
    # Normalize scores
    awq_scores = normalize_scores(awq_scores)
    
    # Save results
    output_dir = os.path.dirname(config['paths']['awq_stats'])
    os.makedirs(output_dir, exist_ok=True)
    
    with open(config['paths']['awq_stats'], 'w') as f:
        json.dump(awq_scores, f, indent=2)
    
    # Print summary statistics
    normalized_scores = [v['awq_score_normalized'] for v in awq_scores.values()]
    print(f"\n[AWQ Score Statistics]")
    print(f"  Layers analyzed: {len(awq_scores)}")
    print(f"  Mean score: {sum(normalized_scores) / len(normalized_scores):.4f}")
    print(f"  Min score: {min(normalized_scores):.4f}")
    print(f"  Max score: {max(normalized_scores):.4f}")
    
    # Show top-10 highest AWQ layers
    sorted_layers = sorted(
        awq_scores.items(),
        key=lambda x: x[1]['awq_score_normalized'],
        reverse=True
    )
    
    print(f"\n[Top 10 Highest AWQ Score Layers]")
    for i, (name, data) in enumerate(sorted_layers[:10]):
        print(f"  {i+1}. {name}: {data['awq_score_normalized']:.4f}")
    
    print(f"\n✓ Step 2 Complete: AWQ Scores")
    print(f"  - Saved to: {config['paths']['awq_stats']}")
    print("\nNext step: python 3_compute_gptq_sensitivity.py")


if __name__ == "__main__":
    main()


"""
Run with:
python 2_compute_awq_scores.py
"""
