#!/bin/bash
# GASQ Quantization Only - For existing gradient stats
# Use this when you already have gradient_stats.json from fine-tuning

set -e

echo "=========================================="
echo "GASQ Quantization (Skip Training)"
echo "=========================================="
echo ""

# Configuration - EDIT THESE
MODEL_PATH="./path/to/your/finetuned/model"        # Your fine-tuned model
GRADIENT_STATS="./path/to/gradient_stats.json"     # Your gradient stats file
OUTPUT_DIR="./quantized_output"                     # Where to save quantized model
CALIBRATION_DATASET="sql"                           # Dataset for calibration: 'sql', 'wikitext', etc.
TARGET_BITS=4.0                                     # Target average bits (4.0 = 3.5GB for 7B)

echo "Configuration:"
echo "  Model: $MODEL_PATH"
echo "  Gradient Stats: $GRADIENT_STATS"
echo "  Output: $OUTPUT_DIR"
echo "  Target: ${TARGET_BITS}-bit average"
echo ""

# Validate inputs
if [ ! -d "$MODEL_PATH" ]; then
    echo "❌ Error: Model directory not found: $MODEL_PATH"
    exit 1
fi

if [ ! -f "$GRADIENT_STATS" ]; then
    echo "❌ Error: Gradient stats file not found: $GRADIENT_STATS"
    exit 1
fi

echo "✓ Files validated"
echo ""

# Run quantization
echo "=========================================="
echo "Running GASQ Quantization..."
echo "=========================================="
echo "This will take approximately 2-3 hours on A100"
echo ""

python quantize_model.py \
    --model_name "$MODEL_PATH" \
    --gradient_stats "$GRADIENT_STATS" \
    --output_dir "$OUTPUT_DIR" \
    --calibration_dataset "$CALIBRATION_DATASET" \
    --target_bits "$TARGET_BITS" \
    --num_calibration_samples 512 \
    --device "cuda"

echo ""
echo "=========================================="
echo "✓ GASQ Quantization Complete!"
echo "=========================================="
echo ""
echo "Output files:"
echo "  Quantized model:  $OUTPUT_DIR/quantized_model/"
echo "  GASQ report:      $OUTPUT_DIR/gasq_report.json"
echo "  AWQ scores:       $OUTPUT_DIR/awq_scores.json"
echo "  GPTQ scores:      $OUTPUT_DIR/gptq_scores.json"
echo ""
echo "Model size: ~3.5-4.2 GB (depending on bit allocation)"
echo ""
echo "Next steps:"
echo "1. Review: $OUTPUT_DIR/gasq_report.json"
echo "2. Test your quantized model"
echo "3. Deploy!"
echo ""
