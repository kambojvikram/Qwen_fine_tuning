"""
Minimal Example: GASQ Quantization with Existing Gradient Stats
Run this if you already have gradient_stats.json from fine-tuning
"""

from gasq_quantizer import GASQQuantizer
from awq_scorer import compute_awq_scores_simple
from gptq_scorer import compute_gptq_scores_simple
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from torch.utils.data import DataLoader
import torch
import json

# ============================================
# CONFIGURATION - EDIT THESE PATHS
# ============================================

MODEL_PATH = "./your-finetuned-model"          # Your fine-tuned model directory
GRADIENT_STATS_PATH = "./gradient_stats.json"  # Your gradient statistics file
OUTPUT_DIR = "./quantized-model"               # Where to save results
CALIBRATION_DATASET = "sql"                    # Dataset for AWQ/GPTQ: 'sql' or 'wikitext'
TARGET_BITS = 4.0                              # Target average bits (4.0 = 3.5GB for 7B)

# ============================================
# STEP 1: Load Model
# ============================================

print("Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True
)

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

# ============================================
# STEP 2: Prepare Calibration Data
# ============================================

print("Loading calibration data...")

if CALIBRATION_DATASET == "sql":
    dataset = load_dataset("gretelai/synthetic_text_to_sql", split="train")
    dataset = dataset.shuffle(seed=42).select(range(512))
    
    def prepare_sample(example):
        text = f"Question: {example['sql_prompt']}\nSQL: {example['sql']}"
        return tokenizer(text, max_length=512, truncation=True, 
                        padding='max_length', return_tensors='pt')
else:
    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
    dataset = dataset.shuffle(seed=42).select(range(512))
    
    def prepare_sample(example):
        return tokenizer(example['text'], max_length=512, truncation=True,
                        padding='max_length', return_tensors='pt')

# Tokenize
tokenized = []
for example in dataset:
    tokens = prepare_sample(example)
    tokenized.append({
        'input_ids': tokens['input_ids'].squeeze(0),
        'attention_mask': tokens['attention_mask'].squeeze(0)
    })

# Create dataloader
def collate_fn(batch):
    return {
        'input_ids': torch.stack([x['input_ids'] for x in batch]),
        'attention_mask': torch.stack([x['attention_mask'] for x in batch])
    }

calibration_loader = DataLoader(tokenized, batch_size=1, collate_fn=collate_fn)

# ============================================
# STEP 3: Compute AWQ Scores
# ============================================

print("\nComputing AWQ scores (activation importance)...")
print("This takes ~30 minutes...")

awq_scores = compute_awq_scores_simple(
    model,
    calibration_loader,
    device="cuda",
    num_batches=128
)

print(f"✓ Computed AWQ scores for {len(awq_scores)} layers")

# Save AWQ scores
with open(f"{OUTPUT_DIR}/awq_scores.json", 'w') as f:
    json.dump(awq_scores, f, indent=2)

# ============================================
# STEP 4: Compute GPTQ Sensitivity
# ============================================

print("\nComputing GPTQ sensitivity scores...")
print("This takes ~45 minutes...")

gptq_scores = compute_gptq_scores_simple(
    model,
    calibration_loader,
    device="cuda",
    num_batches=128
)

print(f"✓ Computed GPTQ scores for {len(gptq_scores)} layers")

# Save GPTQ scores
with open(f"{OUTPUT_DIR}/gptq_scores.json", 'w') as f:
    json.dump(gptq_scores, f, indent=2)

# ============================================
# STEP 5: Initialize GASQ with Your Gradient Stats
# ============================================

print("\nInitializing GASQ with your gradient statistics...")

gasq = GASQQuantizer(
    gradient_stats_path=GRADIENT_STATS_PATH,  # YOUR FILE HERE
    target_avg_bits=TARGET_BITS,
    adaptive_weights=True,
    conservative=True
)

# Add AWQ and GPTQ scores
gasq.awq_scores = awq_scores
gasq.gptq_scores = gptq_scores

# ============================================
# STEP 6: Compute Combined GASQ Scores
# ============================================

print("\nComputing combined GASQ scores...")

gasq.compute_combined_scores()

print(f"✓ Combined {len(gasq.combined_scores)} layers")

# ============================================
# STEP 7: Allocate Bits
# ============================================

print("\nAllocating bits based on GASQ scores...")

gasq.allocate_bits()

# ============================================
# STEP 8: Generate Report
# ============================================

print("\nGenerating GASQ report...")

report = gasq.save_report(f"{OUTPUT_DIR}/gasq_report.json")

print("\n" + "="*60)
print("GASQ QUANTIZATION COMPLETE!")
print("="*60)
print(f"Average bits: {report['results']['avg_bits']:.2f}")
print(f"Compression ratio: {report['results']['compression_ratio']:.2f}x")
print(f"8-bit layers: {report['results']['bit_distribution']['8-bit']}")
print(f"6-bit layers: {report['results']['bit_distribution']['6-bit']}")
print(f"4-bit layers: {report['results']['bit_distribution']['4-bit']}")
print(f"\nEstimated size: {7 / report['results']['compression_ratio']:.2f} GB")
print(f"\nReports saved to: {OUTPUT_DIR}/")
print("="*60)

# ============================================
# STEP 9: Show Top Important Layers
# ============================================

print("\nTop 10 Most Important Layers:")
print("-" * 60)

sorted_layers = sorted(
    gasq.combined_scores.items(),
    key=lambda x: x[1],
    reverse=True
)

for i, (layer_name, score) in enumerate(sorted_layers[:10], 1):
    bits = gasq.bit_allocations[layer_name]
    layer_type = gasq.get_layer_type(layer_name)
    print(f"{i:2}. {layer_name[:50]:50} | {score:.3f} | {bits}-bit | {layer_type}")

print("\n" + "="*60)
print("Next Steps:")
print("1. Review: " + OUTPUT_DIR + "/gasq_report.json")
print("2. Apply quantization using AutoGPTQ (or run quantize_model.py)")
print("3. Test your quantized model")
print("="*60)
