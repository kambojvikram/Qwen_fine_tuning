#!/bin/bash
# GASQ Complete Pipeline Automation Script
# Runs all 6 steps sequentially

set -e  # Exit on error

echo "=========================================="
echo "GASQ Pipeline - Starting Complete Run"
echo "=========================================="

# Check if running distributed
WORLD_SIZE=${WORLD_SIZE:-1}
echo "World size: $WORLD_SIZE"

# Step 1: Train with gradient tracking
echo ""
echo ">>> Step 1/6: Training with Gradient Tracking <<<"
if [ $WORLD_SIZE -gt 1 ]; then
    echo "Running distributed training with $WORLD_SIZE GPUs"
    torchrun --nproc_per_node=$WORLD_SIZE 1_train_with_gradient_tracking.py
else
    echo "Running single-GPU training"
    python 1_train_with_gradient_tracking.py
fi

# Wait for stats to be saved
sleep 5

# Step 2: Compute AWQ scores
echo ""
echo ">>> Step 2/6: Computing AWQ Scores <<<"
python 2_compute_awq_scores.py

# Step 3: Compute GPTQ sensitivity
echo ""
echo ">>> Step 3/6: Computing GPTQ Sensitivity <<<"
python 3_compute_gptq_sensitivity.py

# Step 4: GASQ fusion
echo ""
echo ">>> Step 4/6: GASQ Fusion <<<"
python 4_gasq_fusion.py

# Step 5: Quantize models
echo ""
echo ">>> Step 5/6: Quantizing Models <<<"
python 5_quantize_model.py

# Step 6: Evaluate
echo ""
echo ">>> Step 6/6: Evaluation <<<"
python 6_evaluate.py

echo ""
echo "=========================================="
echo "GASQ Pipeline Complete!"
echo "=========================================="
echo ""
echo "Results saved to:"
echo "  - Gradient stats: ./output/gradient_stats/merged_stats.json"
echo "  - AWQ scores: ./output/awq_stats/awq_scores.json"
echo "  - GPTQ sensitivity: ./output/gptq_stats/gptq_sensitivity.json"
echo "  - GASQ combined: ./output/gasq_stats/gasq_combined.json"
echo "  - Quantized models: ./output/quantized_models/"
echo "  - Evaluation results: ./output/evaluation_results.json"
echo ""
echo "Check evaluation_results.json for deployment decision!"
