"""
Gradient Statistics Tracker for GASQ
Tracks gradient statistics during QLoRA fine-tuning
Based on user's gradient_tracker.py implementation
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional
import json
import time
import threading
import os
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class GradientStatTracker:
    """
    Hook-based gradient statistics tracker for QLoRA fine-tuning.
    Tracks: gradient norms, variance, EMA, max values for importance estimation.
    """
    
    def __init__(
        self,
        model: nn.Module,
        save_path: str = "./gradient_stats",
        save_every_updates: int = 100,
        save_every_seconds: int = 300,
        track_lora_only: bool = True,
        verbose: bool = True
    ):
        """
        Args:
            model: PyTorch model (typically QLoRA model)
            save_path: Directory to save gradient statistics
            save_every_updates: Save every N gradient updates
            save_every_seconds: Save every N seconds
            track_lora_only: Only track LoRA parameters (recommended for QLoRA)
            verbose: Print logging messages
        """
        self.model = model
        self.save_path = Path(save_path)
        self.save_path.mkdir(parents=True, exist_ok=True)
        
        self.save_every_updates = save_every_updates
        self.save_every_seconds = save_every_seconds
        self.track_lora_only = track_lora_only
        self.verbose = verbose
        
        # Statistics storage
        self.stats: Dict[str, Dict[str, Any]] = {}
        self.total_updates = 0
        self.last_save_time = time.time()
        
        # Parameter configurations
        self.param_stats = {
            'ema_fast': 0.1,   # Fast moving average decay
            'ema_slow': 0.9,   # Slow moving average decay
            'variance': 0.99,  # Variance tracking decay
        }
        
        # Register hooks
        self.hooks = []
        self._register_hooks()
        
        # Async saving
        self.lock = threading.Lock()
        
        logger.info(f"GradientStatTracker initialized")
        logger.info(f"Save path: {self.save_path}")
        logger.info(f"Track LoRA only: {track_lora_only}")
    
    def _should_track_param(self, name: str, param: nn.Parameter) -> bool:
        """Determine if parameter should be tracked"""
        if not param.requires_grad:
            return False
        
        if self.track_lora_only:
            # Only track LoRA parameters (lora_A, lora_B)
            return 'lora' in name.lower()
        
        return True
    
    def _get_base_name(self, name: str) -> str:
        """Get base layer name (remove .lora_A, .lora_B suffixes)"""
        # Remove LoRA-specific suffixes for grouping
        base = name.replace('.lora_A', '').replace('.lora_B', '')
        base = base.replace('.default', '')
        return base
    
    def _empty_param_stats(self) -> Dict[str, Any]:
        """Initialize empty statistics for a parameter"""
        return {
            'ema_fast': 0.0,
            'ema_slow': 0.0,
            'variance': 0.0,
            'max_abs': 0.0,
            'sign_consistency': 0.0,
            'sign_flips': 0,
            'update_to_weight_ratio': 0.0,
            'grad_sparsity': 0.0,
            'update_count': 0,
            'welford_n': 0,
            'welford_mean': 0.0,
            'welford_M2': 0.0,
        }
    
    def _register_hooks(self):
        """Register gradient hooks on tracked parameters"""
        for name, param in self.model.named_parameters():
            if self._should_track_param(name, param):
                base = self._get_base_name(name)
                
                # Initialize stats for base layer
                if base not in self.stats:
                    self.stats[base] = {
                        'base': self._empty_param_stats(),
                        'lora_A_stats': self._empty_param_stats() if 'lora' in name else None,
                        'lora_B_stats': self._empty_param_stats() if 'lora' in name else None,
                    }
                
                # Register hook
                hook = param.register_hook(
                    self._create_grad_hook(name, base)
                )
                self.hooks.append(hook)
        
        logger.info(f"Registered gradient hooks on {len(self.hooks)} parameters")
        logger.info(f"Tracking {len(self.stats)} base layers")
    
    def _create_grad_hook(self, param_name: str, base_name: str):
        """Create gradient hook for a parameter"""
        def hook(grad):
            if grad is None:
                return
            
            with self.lock:
                # Determine which stats dict to update
                if 'lora_A' in param_name:
                    side_key = 'lora_A_stats'
                elif 'lora_B' in param_name:
                    side_key = 'lora_B_stats'
                else:
                    side_key = 'base'
                
                s = self.stats[base_name][side_key]
                
                # Compute gradient statistics
                grad_norm = grad.norm().item()
                grad_abs_max = grad.abs().max().item()
                grad_mean = grad.mean().item()
                grad_std = grad.std().item()
                
                # Update EMAs
                ema_fast = self.param_stats['ema_fast']
                ema_slow = self.param_stats['ema_slow']
                
                s['ema_fast'] = ema_fast * grad_norm + (1 - ema_fast) * s['ema_fast']
                s['ema_slow'] = ema_slow * s['ema_slow'] + (1 - ema_slow) * grad_norm
                
                # Update max absolute value seen
                s['max_abs'] = max(s['max_abs'], grad_abs_max)
                
                # Welford's algorithm for variance
                s['welford_n'] += 1
                delta = grad_norm - s['welford_mean']
                s['welford_mean'] += delta / s['welford_n']
                delta2 = grad_norm - s['welford_mean']
                s['welford_M2'] += delta * delta2
                
                if s['welford_n'] > 1:
                    s['variance'] = s['welford_M2'] / (s['welford_n'] - 1)
                
                # Gradient sparsity (fraction of near-zero elements)
                grad_sparsity = (grad.abs() < 1e-8).float().mean().item()
                s['grad_sparsity'] = 0.9 * s['grad_sparsity'] + 0.1 * grad_sparsity
                
                # Update count
                s['update_count'] += 1
        
        return hook
    
    def update(self):
        """Call after each gradient step to update statistics"""
        self.total_updates += 1
        
        # Recompute combined importance heuristic
        for base, entry in self.stats.items():
            self._update_combined_importance(base, entry)
        
        # Periodic save triggers
        now = time.time()
        should_save = (
            (self.total_updates % self.save_every_updates == 0) or
            (now - self.last_save_time >= self.save_every_seconds)
        )
        
        if should_save:
            self._maybe_save_async()
    
    def _update_combined_importance(self, base: str, entry: Dict):
        """Compute combined importance score"""
        # Average across LoRA sides
        side_importances = []
        for side in ['lora_A_stats', 'lora_B_stats']:
            if side in entry and entry[side] is not None:
                s = entry[side]
                if s['update_count'] > 0:
                    ema_fast = s['ema_fast']
                    ema_slow = s['ema_slow']
                    variance = s['variance']
                    max_abs_seen = s['max_abs']
                    
                    # Normalized variance
                    variance_norm = variance / (ema_slow * ema_slow + 1e-8)
                    
                    # Combined importance formula
                    importance = (ema_slow + 0.5 * ema_fast) * \
                                (1 + max_abs_seen / (ema_slow + 1e-8)) * \
                                (1 + variance_norm)
                    
                    side_importances.append(importance)
        
        # Store combined importance
        if side_importances:
            entry['combined_importance'] = sum(side_importances) / len(side_importances)
        else:
            entry['combined_importance'] = 0.0
        
        entry['update_count'] = self.total_updates
    
    def _export_stats(self) -> Dict[str, Any]:
        """Export statistics for saving"""
        export = {}
        for base, entry in self.stats.items():
            layer_out = {
                'combined_importance': entry.get('combined_importance', 0.0),
                'update_count': entry.get('update_count', 0),
            }
            
            # Export side statistics
            for side in ['lora_A_stats', 'lora_B_stats', 'base']:
                if side in entry and entry[side] is not None:
                    key = f'{side}'
                    ps = entry[side]
                    layer_out[key] = {
                        'ema_fast': ps['ema_fast'],
                        'ema_slow': ps['ema_slow'],
                        'variance': ps['variance'],
                        'max_abs': ps['max_abs'],
                        'sign_consistency': ps['sign_consistency'],
                        'sign_flips': ps['sign_flips'],
                        'update_to_weight_ratio': ps['update_to_weight_ratio'],
                        'grad_sparsity': ps['grad_sparsity'],
                        'update_count': ps['update_count'],
                        'welford_n': ps['welford_n'],
                        'welford_mean': ps['welford_mean'],
                        'welford_M2': ps['welford_M2'],
                    }
            
            export[base] = layer_out
        
        return export
    
    def _maybe_save_async(self):
        """Asynchronously save statistics"""
        def write():
            try:
                data = self._export_stats()
                
                # Unique tmp file
                tmp_path = self.save_path / f"stats_{int(time.time()*1000)}.tmp"
                stats_path = self.save_path / "gradient_stats.json"
                
                # Write to temp file
                with open(tmp_path, 'w') as f:
                    json.dump(data, f, indent=2)
                
                # Atomic replace
                tmp_path.replace(stats_path)
                
                if self.verbose:
                    logger.info(f"Saved gradient stats to {stats_path}")
                
            except Exception as e:
                logger.error(f"Failed to save stats: {e}")
        
        # Save in background thread
        threading.Thread(target=write, daemon=True).start()
        self.last_save_time = time.time()
    
    def force_save(self):
        """Immediately save current stats"""
        data = self._export_stats()
        stats_path = self.save_path / "gradient_stats.json"
        
        with open(stats_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        logger.info(f"Force saved gradient stats to {stats_path}")
    
    def summary(self) -> Dict[str, Any]:
        """Return quick importance summary per layer (combined_importance, update_count)"""
        return {
            base: {
                'combined_importance': v.get('combined_importance', 0.0),
                'update_count': v.get('update_count', 0)
            }
            for base, v in self.stats.items()
        }
    
    def get_quantization_recommendations(self) -> Dict[str, str]:
        """
        Get quantization recommendations based on gradient importance.
        Returns dict mapping layer names to recommendation: 'keep_higher_precision', 
        'standard_quantization', or 'aggressive_quantization_candidate'
        """
        items = [
            (layer, data.get('combined_importance', 0.0))
            for layer, data in self.stats.items()
        ]
        items.sort(key=lambda x: x[1], reverse=True)
        
        n = len(items)
        recs = {}
        
        for i, (layer, score) in enumerate(items):
            pct = i / max(1, n - 1)
            
            if pct < 0.2:
                action = 'keep_higher_precision'  # Top 20% -> 8-bit candidate
            elif pct < 0.6:
                action = 'standard_quantization'   # Middle 40% -> 6-bit candidate
            else:
                action = 'aggressive_quantization_candidate'  # Bottom 40% -> 4-bit
            
            recs[layer] = {
                'combined_importance': score,
                'recommendation': action,
            }
        
        return recs
    
    def __del__(self):
        """Cleanup hooks on deletion"""
        for hook in self.hooks:
            hook.remove()
